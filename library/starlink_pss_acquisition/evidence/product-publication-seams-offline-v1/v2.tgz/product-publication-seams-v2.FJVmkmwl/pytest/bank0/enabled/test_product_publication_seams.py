"""Two additive integration seams; offline actors, never vendor/top qualification."""
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from tests.starlink_oracle.product_interface_graph import ancestors, first_cycle, parse
from tests.starlink_oracle.test_checked_product_read import clean_env
from tests.starlink_oracle.test_product_sealed_interface import ORIGINAL_CASES

ROOT = Path(__file__).resolve().parents[2]
ACQ = ROOT / "hdl/library/starlink_pss_acquisition"
BANK = "starlink_pss_epoch_sealed_publication_bank.v"
ISSUER = "starlink_pss_product_sealed_publication_interface.v"
BANK_TB = "tb_starlink_pss_publication_bank.sv"
IF_TB = "tb_starlink_pss_product_sealed_interface.sv"
BASE = ["starlink_pss_epoch_sealed_bank.v", "starlink_pss_block_mailbox.v", BANK]


def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def build(path, kind="bank", option="1", mutation=None):
    path.mkdir()
    names = BASE + (["tb/" + BANK_TB] if kind == "bank" else [
        ISSUER, "starlink_pss_checked_product_read_interface.v",
        "starlink_pss_realtime_input_guard.v", "starlink_pss_realtime_result_guard.v",
        "starlink_pss_spectrum_product.v", "tb/" + IF_TB,
        "tb/product_sealed_interface_cases.svh", "tb/product_publication_seam_cases.svh"])
    for name in names:
        shutil.copyfile(ACQ / name, path / Path(name).name)
    if kind == "bank":
        bench = path / BANK_TB
        bench.write_text(replace_once(bench.read_text(), "parameter integer OPTION=1",
                                     f"parameter integer OPTION={option}"))
        top = BANK_TB.removesuffix(".sv")
    else:
        bench = path / IF_TB
        bench.write_text(interface_bench(bench.read_text(), option))
        top = IF_TB.removesuffix(".sv")
    if mutation:
        name, old, new = mutation
        file = path / name
        file.write_text(replace_once(file.read_text(), old, new))
    for helper in (Path(__file__), Path(__file__).with_name("product_interface_graph.py")):
        shutil.copyfile(helper, path / helper.name)
    (path / "sources.json").write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in path.iterdir() if p.is_file()}, indent=2))
    command = ["iverilog", "-g2012", "-Wall", "-I", ".", "-s", top, "-o", "sim.vvp",
               *[Path(n).name for n in names if not n.endswith(".svh")]]
    p = subprocess.run(command, cwd=path, env=clean_env(), capture_output=True, text=True, timeout=30, check=False)
    (path / "compile.log").write_text(p.stdout + p.stderr)
    (path / "compile.json").write_text(json.dumps({"command": command, "exit": p.returncode}))
    assert p.returncode == 0, p.stderr
    return path


def interface_changes(option):
    return [
        ("starlink_pss_product_sealed_interface #(.SEALED_PRODUCT_ADAPTER(ENABLED)) dut (",
         f"starlink_pss_product_sealed_publication_interface #(.SEALED_PRODUCT_ADAPTER(ENABLED), .SEPARATE_PRODUCT_SEAMS({option})) dut ("),
        (".product_valid(product_valid),.product_ready(product_ready),.product_data",
         ".sampled_product_ready(actual_product_ready),.publication_faults(publication_faults),\n    .product_valid(product_valid),.product_ready(product_ready),.product_data"),
        (".output_valid(product_valid),.output_ready(product_ready)",
         ".output_valid(product_valid),.output_ready(actual_product_ready)"),
        ("product_take !== (product_valid && product_ready)",
         "product_take !== (product_valid && actual_product_ready)"),
        (".external_fault_now(adapter_fault || dut.handoff_fault_now)",
         ".external_fault_now(adapter_fault || dut.handoff_fault_now || publication_faults !== 8'b0)"),
        (".completed_input_fault_now(adapter_fault || dut.handoff_fault_now)",
         ".completed_input_fault_now(adapter_fault || dut.handoff_fault_now || publication_faults !== 8'b0)"),
        ('  `include "product_sealed_interface_cases.svh"',
         '  `include "product_sealed_interface_cases.svh"\n  `include "product_publication_seam_cases.svh"'),
    ]


def interface_bench(source, option="1"):
    for old, new in interface_changes(option):
        source = replace_once(source, old, new)
    return source


def run(path, kind=0, bit=0, target=0):
    command = ["vvp", "sim.vvp", f"+CASE={kind}", f"+BIT={bit}", f"+TARGET={target}"]
    p = subprocess.run(command, cwd=path, env=clean_env(), capture_output=True, text=True, timeout=30, check=False)
    log = p.stdout + p.stderr
    stem = f"case-{kind}-bit-{bit}-target-{target}"
    (path / (stem + ".log")).write_text(log)
    (path / (stem + ".json")).write_text(json.dumps({"command": command, "exit": p.returncode}))
    if not p.returncode:
        assert not re.search(r"(?im)^(?:ERROR|FATAL|FAIL)(?::|\b)", log), log
    return p.returncode, log


@pytest.fixture(scope="module")
def bank(tmp_path_factory):
    return build(tmp_path_factory.mktemp("bank") / "enabled")


@pytest.fixture(scope="module")
def bank_default(tmp_path_factory):
    return build(tmp_path_factory.mktemp("bank") / "disabled", option="0")


@pytest.fixture(scope="module")
def interface(tmp_path_factory):
    return build(tmp_path_factory.mktemp("interface") / "enabled", kind="interface")


@pytest.mark.parametrize("phase", range(6))
@pytest.mark.parametrize("bit", range(8))
@pytest.mark.parametrize("value", range(3))
def test_bank_current_publication_categories_and_observation_window(bank, phase, bit, value):
    code, log = run(bank, phase, bit, value)
    assert code == 0 and "PUBLICATION_BANK_" in log and "PASS" in log, log


@pytest.mark.parametrize("phase", range(7))
def test_bank_disabled_whole_state_equivalence(bank_default, phase):
    code, log = run(bank_default, phase, 7, 2)
    assert code == 0 and "PASS" in log, log


def test_interface_healthy_eight_leases(interface):
    code, log = run(interface)
    assert code == 0 and "PRODUCT_ADAPTER_PASS case=0 jobs=8" in log, log
    assert "PRODUCT_INTERFACE_ORDER_COUNTS admissions=8 completions=8" in log, log


@pytest.mark.parametrize("kind,bit,target", ORIGINAL_CASES)
def test_literal_old_composed_cases(interface, kind, bit, target):
    code, log = run(interface, kind, bit, target)
    assert code == 0 and "PASS" in log, log


def test_fixture_full_inverse():
    original = (ACQ / "tb" / IF_TB).read_text()
    assert hashlib.sha256(original.encode()).hexdigest() == "3c13624cef0dc13668e4a47d8e85e3b5c1b889e6b28a192c6fd9f28446b5a6fc"
    for option in ("0", "1"):
        result = interface_bench(original, option)
        for old, new in reversed(interface_changes(option)):
            result = replace_once(result, new, old)
        assert result == original


SEAM_CASES = [(200, 0, t) for t in (37, 511)] + [(201, b, t) for b in range(2) for t in (37, 511)] + [
    (202, b, 0) for b in range(3)] + [(203, 0, 0)] + [(204, b, t) for b in range(24) for t in range(2)] + [
    (205, b, 0) for b in range(24)] + [(206, 0, 0)]


@pytest.mark.parametrize("kind,bit,target", SEAM_CASES)
def test_new_actual_ready_and_publication_boundaries(interface, kind, bit, target):
    code, log = run(interface, kind, bit, target)
    assert code == 0 and "PRODUCT_SEAM_" in log and "PASS" in log, log
    if kind == 200 and target == 511:
        assert "PRODUCT_ADAPTER_PASS case=200 jobs=1" in log and "edges=4" in log, log


def graph_receipt(path):
    graph, names = parse((path / "sim.vvp").read_text())
    cycle = first_cycle(graph)
    receipt = {"nodes": len(graph), "LS": sum(n.startswith("LS_") for n in graph), "cycle": cycle}
    (path / "graph.json").write_text(json.dumps(receipt, indent=2))
    return graph, names, cycle


def test_complete_publication_coupled_graph_is_acyclic(interface):
    graph, names, cycle = graph_receipt(interface)
    assert not cycle, cycle
    assert sum(n.startswith("LS_") for n in graph) > 0
    source = set(names["publication_faults"])
    for sink in ("bank_live", "output_valid", "certificate_ready", "lease_release_ready", "lease_release"):
        assert not (ancestors(graph, names[sink]) & source), sink


@pytest.mark.parametrize("mutation", [
    (ISSUER, "wire [7:0] bank_live = current_faults |", "wire [7:0] bank_live = current_faults | publication_faults |"),
    (BANK, "wire local_current_clean = errors_now == 0;", "wire local_current_clean = errors_now == 0 && publication_faults === 8'b0;"),
    (BANK, "assign output_valid = running && armed", "assign output_valid = publication_only_clean && running && armed"),
])
def test_executed_restored_publication_backedges(tmp_path, mutation):
    path = build(tmp_path / "backedge", kind="interface", mutation=mutation)
    _, _, cycle = graph_receipt(path)
    assert cycle, "RESTORED_BACKEDGE_WAS_NOT_REJECTED"
