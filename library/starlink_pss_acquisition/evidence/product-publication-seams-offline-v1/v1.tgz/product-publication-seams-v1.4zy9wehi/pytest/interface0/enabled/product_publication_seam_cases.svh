// Added only in a mechanically derived copy of the immutable1444 fixture.
// Actual arithmetic READY and advertised capacity are distinct force targets.
  wire actual_product_ready=product_ready;
  reg [7:0] publication_injection=0;
  reg publication_feedback_enabled=0;
  // Deliberately modeled caller coupling: real checked-input certificates
  // route only to publication plus the independent result guard fence.
  wire [7:0] publication_faults=publication_injection |
    {6'b0,publication_feedback_enabled && consumer_complete,
     publication_feedback_enabled && consumer_beat};
