"""Producer-local final-only authorization; no vendor FFT or controller proof."""
import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from tests.starlink_oracle.test_exact_control import STUB

ROOT = Path(__file__).resolve().parents[2]
ACQ = ROOT / "hdl/library/starlink_pss_acquisition"
RECIPE = json.loads(Path(__file__).with_name("product_final_fence_delta.json").read_text())
TOP = "starlink_pss_fft_bank_owned_product_fence"
MAIL = "starlink_pss_product_fence_mailbox"
BENCH = "tb_starlink_pss_product_final_fence"


def frozen(name):
    return subprocess.check_output(["git", "-C", str(ROOT / "hdl"), "show",
        RECIPE["base"] + f":library/starlink_pss_acquisition/{name}.v"], text=True)


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new, 1)


def restored(source, name):
    for old, new in reversed(RECIPE["modules"][name]["edits"]):
        source = once(source, new, old)
    return source


def test_whole_module_inverse_and_all_original_runtime_unchanged():
    for name, record in RECIPE["modules"].items():
        source = (ACQ / f"{name}.v").read_text()
        old = frozen(record["original"])
        assert restored(source, name) == old
        assert (ACQ / f'{record["original"]}.v').read_text() == old
    for name in ("starlink_pss_realtime_input_guard", "starlink_pss_realtime_result_guard",
                 "starlink_pss_forward_kernel_join_read_ahead", "starlink_pss_kernel_rom_read_ahead",
                 "starlink_pss_spectrum_product"):
        assert (ACQ / f"{name}.v").read_text() == frozen(name)


def wire(source, name):
    return re.search(r"  wire " + name + r" = .*?;", source, re.S)[0]


def test_only_sampled_final_select_changes_and_excluded_cones_absent():
    top = (ACQ / f"{TOP}.v").read_text()
    mail = (ACQ / f"{MAIL}.v").read_text()
    terms = re.findall(r"\b\w+(?:\[\d\])?\b", wire(top, "producer_final_fault_now").split("=", 1)[1])
    assert terms == ["duplicate_start_fault_now", "input_guard_fault", "source_fault_fast[1]",
        "vendor_fault_now", "fast_fault", "kernel_fault", "product_overflow", "product_bank_fault",
        "product_bank_framing_fault_now", "result_fault"]
    assert "input_fault_now" not in terms and "handoff_fault_now" not in terms
    old = frozen("starlink_pss_fft_bank_owned_rom_read_ahead")
    for name in ("external_fault_now", "product_commit_authorized", "forward_handoff_ack",
                 "completion_accept", "any_fast_fault"):
        assert wire(top, name) == wire(old, name)
    assert mail.count("input_final_seal_authorized") == 2  # port + final-only select
    assert "if (write_position == LAST_POSITION) begin\n          if (!EXPLICIT_COMMIT || (USE_PRODUCER_FINAL_FENCE ?" in mail


def run(tmp_path, enabled=1, width=2, mutate_top=None, mutate_mail=None, broken=0):
    top = (ACQ / f"{TOP}.v").read_text()
    mail = (ACQ / f"{MAIL}.v").read_text()
    if mutate_top:
        top = once(top, *mutate_top)
    if mutate_mail:
        mail = once(mail, *mutate_mail)
    (tmp_path / "candidate.v").write_text(mail)
    (tmp_path / "reference.v").write_text(once(frozen("starlink_pss_block_mailbox"),
        "module starlink_pss_block_mailbox #(", "module frozen_product_mailbox #("))
    shutil.copyfile(ACQ / "starlink_pss_realtime_input_guard.v", tmp_path / "guard.v")
    old = frozen("starlink_pss_fft_bank_owned_rom_read_ahead")
    predicates = "\n".join([wire(old, "external_fault_now"), wire(old, "product_commit_authorized"),
        wire(top, "producer_final_fault_now"), wire(top, "producer_final_seal_authorized")])
    bench = once((ACQ / f"tb/{BENCH}.sv").read_text(),
                 "  // FROZEN_AND_CANDIDATE_PREDICATES", predicates)
    (tmp_path / "bench.sv").write_text(bench)
    result = subprocess.run(["iverilog", "-g2012", "-Wall", "-s", BENCH,
        f"-P{BENCH}.ENABLED={enabled}", f"-P{BENCH}.ADDRESS_WIDTH={width}",
        f"-P{BENCH}.BROKEN_CALLER={broken}", "-o", "sim.vvp", "candidate.v",
        "reference.v", "guard.v", "bench.sv"], cwd=tmp_path, capture_output=True,
        text=True, timeout=30)
    (tmp_path / "compile.log").write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    result = subprocess.run(["vvp", "sim.vvp"], cwd=tmp_path, capture_output=True,
                            text=True, timeout=60)
    (tmp_path / "simulate.log").write_text(result.stdout + result.stderr)
    return result.returncode, result.stdout + result.stderr


@pytest.mark.parametrize("enabled,width", [(0, 2), (1, 2), (0, 9), (1, 9)])
def test_real_checker_paired_mailbox_all_public_state_data_and_sampled_fence(tmp_path, enabled, width):
    code, log = run(tmp_path, enabled, width)
    assert code == 0 and log.count("PRODUCT_FINAL_FENCE_PASS") == 1, log
    assert "input_bits=70 final_rows=71 current_rows=7 inverse_epochs=1" in log
    assert "epoch_resets=2" in log and f"words={1 << width}" in log
    assert re.search(r"nonsampled_private=[1-9]\d*", log)


@pytest.mark.parametrize("term", ["duplicate_start_fault_now", "source_fault_fast[1]",
    "vendor_fault_now", "kernel_fault", "product_overflow", "result_fault"])
def test_current_missing_veto_mutants_rejected_on_real_final_edge(tmp_path, term):
    source = (ACQ / f"{TOP}.v").read_text()
    before = wire(source, "producer_final_fault_now")
    after = before.replace(term, "1'b0")
    with pytest.raises(AssertionError):
        restored(once(source, before, after), TOP)
    code, log = run(tmp_path, mutate_top=(before, after))
    assert code != 0 and "SAMPLED_FINAL_AUTHORIZATION_MISMATCH" in log, log


def test_raw_private_publication_mutant_rejected(tmp_path):
    code, log = run(tmp_path, mutate_mail=(
        "input_final_seal_authorized : input_commit_authorized", "1'b1 : input_commit_authorized"))
    assert code != 0 and "PRODUCT_PUBLIC_STATE_MISMATCH" in log, log


def test_deliberately_broken_active_input_caller_is_not_equivalence(tmp_path):
    code, log = run(tmp_path, broken=1)
    assert code != 0 and "PRODUCER_FINAL_CALLER_INVARIANT_BROKEN" in log, log


@pytest.mark.parametrize("name,knob", [(TOP, "PRODUCER_LOCAL_FINAL_FENCE"), (MAIL, "USE_PRODUCER_FINAL_FENCE")])
@pytest.mark.parametrize("value", ["-1", "2", "32'bx", "32'bz"])
def test_invalid_knobs_fail_closed_before_execution(tmp_path, name, knob, value):
    sources = list(ACQ / f"{n}.v" for n in (
        TOP, MAIL, "starlink_pss_block_mailbox", "starlink_pss_realtime_input_guard",
        "starlink_pss_realtime_result_guard", "starlink_pss_forward_kernel_join_read_ahead",
        "starlink_pss_kernel_rom_read_ahead", "starlink_pss_spectrum_product"))
    (tmp_path / "stub.v").write_text(STUB)
    (tmp_path / "kernel.mem").write_text("000000000\n" * 512)
    command = ["iverilog", "-g2012", "-s", name, f"-P{name}.{knob}={value}",
               "-o", "sim.vvp", *map(str, sources), "stub.v"]
    result = subprocess.run(command, cwd=tmp_path, capture_output=True, text=True, timeout=30)
    (tmp_path / "compile.log").write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    result = subprocess.run(["vvp", "sim.vvp"], cwd=tmp_path, capture_output=True, text=True, timeout=10)
    log = result.stdout + result.stderr
    (tmp_path / "simulate.log").write_text(log)
    assert result.returncode != 0 and f"{knob} must be zero or one" in log
    assert "Time: 0 " in log
