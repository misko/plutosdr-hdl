`timescale 1ns/1ps
module binding;
  reg clk=0,fft_clk=0,resetn=0,fft_resetn=0;
  always #5 clk=~clk;always #3 fft_clk=~fft_clk;
`define PORTS .clk(clk),.fft_clk(fft_clk),.resetn(resetn),.fft_resetn(fft_resetn),.input_valid(1'b0),.input_data(36'b0),.input_position(9'b0),.input_last(1'b0),.input_block_start(64'b0),.output_ready(1'b0)
`define OPTIONS .REGISTERED_SCHEDULING(1),.DISTRIBUTED_FAST_FAULT(1),.PER_CAUSE_FAULT_CDC(1),.PRIVATE_NEXT_START_SCRATCH(1),.PRIVATE_ROM_READ_AHEAD(1),.PRIVATE_BLOCK_METADATA_READ_AHEAD(1)
  starlink_pss_fft_bank_owned_product_fence #(`OPTIONS,.PRODUCER_LOCAL_FINAL_FENCE(1)) dut (`PORTS);
  frozen_top #(`OPTIONS) old (`PORTS);
`define VIEW(m) {m.fast_running,m.slow_running,m.input_ready,m.output_valid,m.output_data,m.output_position,m.output_last,m.output_metadata,m.fault,m.state,m.core_release,m.fast_fault,m.product_commit_authorized,m.product_bank.request_toggle,m.product_bank.acknowledge_toggle}
  integer checks=0;
  always @(posedge clk or posedge fft_clk) begin
    #0.001;
    if (`VIEW(dut)!==`VIEW(old)) $fatal(1,"QUIESCENT_TOP_RESET_SHADOW_MISMATCH");
    checks=checks+1;
  end
  initial begin
    #0.002;
    if(dut.product_bank.USE_PRODUCER_FINAL_FENCE!==1) $fatal(1,"TOP_FINAL_FLAG_FORWARDING_MISMATCH");
    #23;resetn=1;fft_resetn=1;#101;
    resetn=0;#31;resetn=1;#101;
    fft_resetn=0;#31;fft_resetn=1;#101;
    if(checks<50 || !dut.fast_running || !dut.slow_running) $fatal(1,"TOP_RESET_COVERAGE_MISSING");
    $display("PRODUCT_FINAL_TOP_BINDING_PASS enabled=%0d checks=%0d one_sided=2 scope=parked_FFT_no_active_or_paused_clock_reset_claim",1,checks);
    $finish;
  end
endmodule
