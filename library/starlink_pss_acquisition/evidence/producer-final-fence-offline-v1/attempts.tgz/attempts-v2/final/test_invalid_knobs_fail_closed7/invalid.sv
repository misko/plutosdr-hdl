module invalid; starlink_pss_product_fence_mailbox #(.USE_PRODUCER_FINAL_FENCE(32'bz)) dut (); endmodule
