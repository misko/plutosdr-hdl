module invalid; starlink_pss_product_fence_mailbox #(.USE_PRODUCER_FINAL_FENCE(-1)) dut (); endmodule
