module invalid; starlink_pss_fft_bank_owned_product_fence #(.PRODUCER_LOCAL_FINAL_FENCE(-1)) dut (); endmodule
