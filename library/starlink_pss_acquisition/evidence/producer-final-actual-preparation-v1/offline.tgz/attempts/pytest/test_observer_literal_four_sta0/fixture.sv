`timescale 1ns/1fs
module fixture;
  reg clk=0;always #3 clk=~clk;
  reg in_running=0,input_accept=0,input_framing_valid=1;
  reg [8:0] write_position=0;
  reg old_authorized=0,new_authorized=0,forward_committed=1;
  reg slot_open=0,checked_complete=1,inverse_phase=0,guard_phase=0;
  reg input_fault_now=0,duplicate_start=0,handoff_fault_now=0;
  reg request_toggle=0,reading=0,read_valid=0;
  wire acknowledge_stage1=request_toggle;
  reg public_ready=1,public_valid=0,fast_running=1,current_fault=0,core_resetn=1,output_ready=0;
  starlink_pss_product_final_actual_observer monitor(.*);
  // Independent literal OLD mailbox request recurrence, not the new fence.
  always @(posedge clk)
    if (!in_running) request_toggle<=0;
    else if (input_accept) begin
      if (!input_framing_valid) begin end
      else if (write_position==511) begin
        if (old_authorized) request_toggle<=!request_toggle;
      end
    end
  function automatic reg four(input integer n);
    case(n) 0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
  endfunction
  task tick;begin @(posedge clk);#0.002;end endtask
  initial begin
    tick();@(negedge clk);
    for(integer a=0;a<4;a=a+1) for(integer b=0;b<4;b=b+1)
      for(integer c=0;c<4;c=c+1) for(integer d=0;d<4;d=d+1) for(integer e=0;e<4;e=e+1) begin
        @(negedge clk);in_running=four(a);input_accept=four(b);input_framing_valid=four(c);
        case(d) 0:write_position=0;1:write_position=511;2:write_position='x;3:write_position='z;endcase
        old_authorized=four(e);new_authorized=four(e);public_valid=1;tick();
      end
      if(monitor.sampled!=36 || monitor.unknown_authorization!=18 || monitor.public_overlap<1024)
        $fatal(1,"FOUR_STATE_BRANCH_COUNT_MISMATCH");
    $display("PRODUCT_FINAL_OBSERVER_FIXTURE_PASS sampled=%0d unknown=%0d overlap=%0d",monitor.sampled,monitor.unknown_authorization,monitor.public_overlap);
    $finish;
  end
endmodule
