"""Literal disabled actual harness preparation; compilation is actor-only."""
import hashlib
import json
import re
import runpy
import shutil
import subprocess
from pathlib import Path

import pytest

from tests.starlink_oracle.test_checked_product_read import clean_env

ROOT = Path(__file__).resolve().parents[2]
ACQ = ROOT / "hdl/library/starlink_pss_acquisition"
HELPER = ACQ / "prepare_checked_product_actual.py"
API = runpy.run_path(str(HELPER))
ORIGIN = Path("/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/product-final-actual-prepared-v1")


@pytest.fixture(scope="module")
def prepared(tmp_path_factory):
    root = tmp_path_factory.mktemp("disabled_actual")
    output = root / "prepared"
    result = API["prepare_disabled"](ORIGIN, output)
    (root / "preparation-receipt.json").write_text(json.dumps(result, indent=2))
    shutil.copyfile(HELPER, root / HELPER.name)
    shutil.copyfile(Path(__file__), root / Path(__file__).name)
    return output


def test_whole_old_bench_and_binding_restore(prepared):
    for name in API["ORIGINAL_SHA"]:
        new = (prepared / "frozen_sources" / name).read_text()
        old = (ORIGIN / "frozen_sources" / name).read_text()
        assert API["disabled_source"](name, new, inverse=True) == old
        # Old independent reference names are untouched, not redirected to
        # candidate hierarchy by a global replacement.
        assert new.count("exact_reference.dut.product_bank.") == old.count("exact_reference.dut.product_bank.")
    assert API["verify_disabled"](prepared)["runtime_modules"] == 14
    assert (prepared / "frozen_sources/simulate_exact_control_prepared.tcl").read_bytes() == (
        ORIGIN / "frozen_sources/simulate_exact_control_prepared.tcl").read_bytes()


def test_disabled_harness_elaborates_with_declared_control_actor_only(prepared, tmp_path):
    path = tmp_path / "compile"
    shutil.copytree(prepared / "frozen_sources", path)
    actor = ACQ / "tb/starlink_pss_fft512_control_actor.v"
    assert hashlib.sha256(actor.read_bytes()).hexdigest() == "a34d57daba44372d74c364dd6dd1b4acd898dcf9052814923eb5cc01e4b8f333"
    shutil.copyfile(actor, path / actor.name)
    command = ["iverilog", "-g2012", "-Wall", "-I.", "-s", "tb_starlink_pss_fft_bank_owned_slice",
               "-Ptb_starlink_pss_fft_bank_owned_slice.FAST_MHZ=175",
               *[f"-Ptb_starlink_pss_fft_bank_owned_slice.{key}=1" for key in (
                   "REGISTERED_SCHEDULING", "DISTRIBUTED_FAST_FAULT", "PRIVATE_NEXT_START_SCRATCH",
                   "PER_CAUSE_FAULT_CDC", "PRIVATE_ROM_READ_AHEAD", "PRIVATE_BLOCK_METADATA_READ_AHEAD",
                   "PRODUCER_LOCAL_FINAL_FENCE", "EXACT_EXTRA_EPOCHS")],
               "-o", "sim.vvp", *sorted(p.name for p in path.iterdir() if p.suffix in (".sv", ".v"))]
    result = subprocess.run(command, cwd=path, env=clean_env(), capture_output=True,
                            text=True, timeout=30, check=False)
    (path / "compile.log").write_text(result.stdout + result.stderr)
    (path / "compile.json").write_text(json.dumps({"command": command, "exit": result.returncode,
        "scope": "actor_elaboration_only_NO_vvp_NO_vendor_NO_numerical_claim"}, indent=2))
    (path / "sources.json").write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in path.iterdir() if p.is_file() and p.suffix in (".v", ".sv", ".svh", ".mem")}, indent=2))
    assert result.returncode == 0 and not re.search(r"(?im)error:", result.stderr), result.stderr


@pytest.mark.parametrize("name", list(API["RUNTIME_SHA"]))
def test_every_runtime_source_is_fixed(prepared, tmp_path, name):
    copy = tmp_path / "prepared"
    shutil.copytree(prepared, copy)
    target = copy / "frozen_sources" / name
    target.write_text(target.read_text() + "\n// changed frozen RTL\n")
    with pytest.raises(ValueError, match="changed"):
        API["verify_disabled"](copy)


@pytest.mark.parametrize("name", [
    "starlink_pss_fault_cdc_actual_observer.svh", "starlink_pss_rom_actual_observer.svh",
    "starlink_pss_forward_retirement_shadow.sv", "starlink_pss_exact_control_extra_epochs.svh",
    "starlink_pss_payload_bubble_shadow.sv", "prepare_exact_control_status_qualified.py",
    "samples_ci16.mem", "forward_q17.mem", "product_q17.mem", "inverse_q17.mem",
    "create_shared_realtime_xfft_ip.tcl", "simulate_exact_control_prepared.tcl",
])
def test_every_inherited_policy_remains_bound(prepared, tmp_path, name):
    copy = tmp_path / "prepared"
    shutil.copytree(prepared, copy)
    target = copy / "frozen_sources" / name
    target.write_bytes(target.read_bytes() + b"\n")
    with pytest.raises(ValueError, match="inherited body changed"):
        API["verify_disabled"](copy)


@pytest.mark.parametrize("old,new", [
    (".CHECKED_PRODUCT_BANK(0)", ".CHECKED_PRODUCT_BANK(1)"),
    ("EXACT_EXTRA_COVERAGE_MISSING", "WEAKENED_COVERAGE"),
    ("inverse output mismatch/invalid publication", "WEAKENED_NUMERICAL_CHECK"),
    ("exact_reference.dut.product_bank.request_toggle", "exact_reference.dut.original_product_bank.product_bank.request_toggle"),
])
def test_whole_observer_inverse_rejects_edits(prepared, old, new):
    source = (prepared / "frozen_sources" / API["TOP"]).read_text()
    if old == "EXACT_EXTRA_COVERAGE_MISSING":
        # The included file is separately immutable, not flattened into the bench.
        source = source.replace("EXACT_ACTUAL_REFERENCE_OR_COVERAGE_INCOMPLETE", new)
    else:
        assert old in source
        source = source.replace(old, new, 1)
    with pytest.raises(ValueError):
        API["disabled_source"](API["TOP"], source, inverse=True)


def test_no_overwrite_symlink_or_extra_actor(prepared, tmp_path):
    with pytest.raises(FileExistsError):
        API["prepare_disabled"](ORIGIN, prepared)
    link = tmp_path / "aliased"
    link.symlink_to(prepared, target_is_directory=True)
    with pytest.raises(ValueError, match="aliased"):
        API["verify_disabled"](link)
    copy = tmp_path / "copy"
    shutil.copytree(prepared, copy)
    (copy / "frozen_sources/starlink_pss_fft512_control_actor.v").write_text("module fake;endmodule\n")
    with pytest.raises(ValueError, match="unexpected"):
        API["verify_disabled"](copy)


def test_source_specific_cli_from_root(prepared):
    result = subprocess.run(["/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python", "-B", str(HELPER),
                             "--verify-disabled", str(prepared)], cwd="/", env=clean_env(),
                            capture_output=True, text=True, timeout=30, check=False)
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout)["scope"] == "disabled_compile_only_NOT_vendor_admission"
