"""Source-specific actual preparation; currently the literal disabled control.

No vendor commands. Enabled observer/binding adaptations remain a review seam.
The copied original runner is intentionally NOT admitted by its original source
verifier after this transformation. Do not treat offline elaboration as a run.
"""
import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path

ORIGIN_INVENTORY = "7adf2efa0a242b89ccfbb387b00210e76841ba544cbae4cef97efc861acf59b2"
TOP = "tb_starlink_pss_fft_bank_owned_slice.sv"
BINDING = "starlink_pss_product_final_actual_binding.svh"
ORIGINAL_SHA = {
    TOP: "68aab9352336490972dba7b05b59c9fcd6c3a813f741af8ee4590f25aec7870b",
    BINDING: "4b04032bb8eda1d597cc03b972c02839880caf4b28bf70de2176dda43fca3211",
}
RUNTIME_SHA = {
    "starlink_pss_fft_bank_owned_checked_product.v": "56f341f02623698d23e66a4b46146eaaca29a25de36aad1b3cdfa5f1d56ed062",
    "starlink_pss_fft_bank_owned_product_fence.v": "8923b42b3574fc1418eee99c5f5819f173c73fbf7b8bb65726a7ab3a5d8a6f7c",
    "starlink_pss_realtime_checked_product_input_guard.v": "7e0b6e674a8c70898c050571f66513fd06208c9738954385a3d3207d0cc65d37",
    "starlink_pss_realtime_input_guard.v": "eb1f968a30ae0371421cfb0766c7f8bf0c23411e730717cd0d4924be0604109e",
    "starlink_pss_realtime_result_guard_observe.v": "b052874e6f1e40d5ee1149256fe89a47abdf35cb06f7a9b46c5c4d4615dcc22e",
    "starlink_pss_realtime_result_guard.v": "09ab35339d55ddf88e813830322d21574d0794c489c9749f68113e9da7807be2",
    "starlink_pss_checked_product_read_observe.v": "222d09935af40ccd742f6df7344ae6c6682edb435b65fd7481877bdd33b2b344",
    "starlink_pss_product_sealed_observe.v": "386323152dff509f64688a1d3ea6827d6fb668430365180396df7baf94910f15",
    "starlink_pss_epoch_sealed_publication_bank.v": "76d6985aa2148776ee1e834307066575d269878dc2c32cffd2bdbb87f2c5a490",
    "starlink_pss_block_mailbox.v": "e85122eb6689ff49b31aa5a0c200e2666786629055b4f45856fe79fb829dbb55",
    "starlink_pss_product_fence_mailbox.v": "e4f4c56ddab8f05d0f9b9da9a75f975e11cb8ad441581c904bfb094f3013982f",
    "starlink_pss_forward_kernel_join_read_ahead.v": "191124c2ddadf1b6d7c56fa029ac2a8e952a75d9c174c2b6a7f6e8283b53365b",
    "starlink_pss_kernel_rom_read_ahead.v": "d35020ea933637d96f1d197322110d4c436566e9e03870732082a55dc7d2cee4",
    "starlink_pss_spectrum_product.v": "f4fd79f2744cbaf4d7caa6afdf2781ab588fff612266cdb377593bbb31076669",
}
ALIASES = {TOP: 144, BINDING: 19}
OLD_MODULE = "  starlink_pss_fft_bank_owned_product_fence #(" 
NEW_MODULE = "  starlink_pss_fft_bank_owned_checked_product #(" 
OLD_PARAMETER = "    .PRODUCER_LOCAL_FINAL_FENCE(PRODUCER_LOCAL_FINAL_FENCE)) dut (.*);"
NEW_PARAMETER = "    .PRODUCER_LOCAL_FINAL_FENCE(PRODUCER_LOCAL_FINAL_FENCE),\n    .CHECKED_PRODUCT_BANK(0)) dut (.*);"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def no_links(path):
    if any(item.is_symlink() for item in (path, *path.parents)):
        raise ValueError("aliased checked-product preparation path")


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("changed checked-product literal anchor")
    return text.replace(old, new, 1)


def disabled_source(name, body, inverse=False):
    """Whole-file inverse, including every old observer/stimulus byte."""
    if name not in ORIGINAL_SHA:
        raise ValueError("unknown disabled source")
    if not inverse and digest(body.encode()) != ORIGINAL_SHA[name]:
        raise ValueError("original disabled source changed")
    if name == TOP:
        if inverse:
            body = once(body, NEW_PARAMETER, OLD_PARAMETER)
            body = once(body, NEW_MODULE, OLD_MODULE)
        else:
            body = once(body, OLD_MODULE, NEW_MODULE)
            body = once(body, OLD_PARAMETER, NEW_PARAMETER)
    before, after = "dut.product_bank.", "dut.original_product_bank.product_bank."
    if inverse:
        before, after = after, before
    # Negative prefix prevents changing exact_reference.dut and diagnostic
    # reference operands; only actual candidate mailbox names are relocated.
    body, count = re.subn(r"(?<![A-Za-z0-9_.])" + re.escape(before), after, body)
    if count != ALIASES[name]:
        raise ValueError("candidate-only mailbox alias inventory changed")
    if inverse and digest(body.encode()) != ORIGINAL_SHA[name]:
        raise ValueError("whole original observer/stimulus inverse changed")
    return body


def origin_files(origin):
    no_links(origin)
    manifest = origin / "SHA256SUMS"
    no_links(manifest)
    if digest(manifest.read_bytes()) != ORIGIN_INVENTORY:
        raise ValueError("not the passing full P1 inventory")
    result = {}
    for line in manifest.read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = Path(name)
        if path.is_absolute() or ".." in path.parts or name in result:
            raise ValueError("invalid inherited inventory path")
        target = origin / path
        no_links(target)
        body = target.read_bytes()
        if digest(body) != expected:
            raise ValueError("inherited source changed: " + name)
        result[name] = body
    if len(result) != 65:
        raise ValueError("incomplete inherited source closure")
    return result


def verify_disabled(output):
    """Offline source integrity, not old actual result or vendor admission."""
    no_links(output)
    metadata = json.loads((output / "checked-preparation.json").read_text())
    if metadata["scope"] != "disabled_compile_only_NOT_vendor_admission" or metadata["enabled"] != 0:
        raise ValueError("disabled preparation scope changed")
    origin_manifest = (output / "checked-passing-P1-SHA256SUMS").read_bytes()
    if digest(origin_manifest) != ORIGIN_INVENTORY:
        raise ValueError("changed inherited manifest")
    source = output / "frozen_sources"
    rows = {}
    for line in origin_manifest.decode().splitlines():
        expected, name = line.split("  ", 1)
        target = output / name
        no_links(target)
        body = target.read_bytes()
        if name in ("frozen_sources/" + TOP, "frozen_sources/" + BINDING):
            body = disabled_source(Path(name).name, body.decode(), inverse=True).encode()
        if digest(body) != expected:
            raise ValueError("full inherited body changed: " + name)
        rows[name] = expected
    if len(rows) != 65:
        raise ValueError("incomplete inherited closure")
    for name, expected in RUNTIME_SHA.items():
        no_links(source / name)
        if digest((source / name).read_bytes()) != expected:
            raise ValueError("frozen runtime changed: " + name)
    expected_files = set(rows) | {"frozen_sources/" + name for name in RUNTIME_SHA}
    expected_files |= {"checked-passing-P1-SHA256SUMS", "checked-preparation.json", "SHA256SUMS"}
    actual_files = {str(p.relative_to(output)) for p in output.rglob("*") if p.is_file()}
    if actual_files != expected_files:
        raise ValueError("unexpected/missing offline source")
    return {"scope": metadata["scope"], "enabled": 0, "runtime_modules": len(RUNTIME_SHA),
            "inherited_members": len(rows), "whole_original_bodies_restored": [TOP, BINDING]}


def prepare_disabled(origin, output, acq=None):
    no_links(output)
    if output.exists():
        raise FileExistsError("refusing existing checked-product preparation")
    original = origin_files(origin)
    acq = Path(__file__).resolve().parent if acq is None else acq
    runtime = {}
    for name, expected in RUNTIME_SHA.items():
        no_links(acq / name)
        body = (acq / name).read_bytes()
        if digest(body) != expected:
            raise ValueError("unqualified runtime source: " + name)
        runtime[name] = body
    output.mkdir(parents=True)
    for name, body in original.items():
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
    source = output / "frozen_sources"
    for name in ORIGINAL_SHA:
        old = (source / name).read_text()
        new = disabled_source(name, old)
        if disabled_source(name, new, inverse=True) != old:
            raise ValueError("disabled whole-source inverse failed")
        (source / name).write_text(new)
    for name, body in runtime.items():
        if (source / name).exists() and name not in ORIGINAL_SHA:
            if (source / name).read_bytes() != body:
                raise ValueError("inherited runtime collision")
        (source / name).write_bytes(body)
    shutil.copyfile(origin / "SHA256SUMS", output / "checked-passing-P1-SHA256SUMS")
    (output / "checked-preparation.json").write_text(json.dumps({
        "scope": "disabled_compile_only_NOT_vendor_admission", "enabled": 0,
        "origin": str(origin), "runtime_sha256": RUNTIME_SHA,
        "source_helper_sha256": digest(Path(__file__).read_bytes()),
        "candidate_mailbox_aliases": ALIASES}, indent=2))
    (output / "SHA256SUMS").write_text("".join(
        f"{digest(p.read_bytes())}  {p.relative_to(output)}\n"
        for p in sorted(output.rglob("*")) if p.is_file() and p != output / "SHA256SUMS"))
    return verify_disabled(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--origin", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--verify-disabled", type=Path)
    args = parser.parse_args()
    if args.verify_disabled is not None:
        result = verify_disabled(args.verify_disabled)
    elif args.origin is not None and args.output is not None:
        result = prepare_disabled(args.origin, args.output)
    else:
        parser.error("requires --origin/--output or --verify-disabled")
    print(json.dumps(result, sort_keys=True))
