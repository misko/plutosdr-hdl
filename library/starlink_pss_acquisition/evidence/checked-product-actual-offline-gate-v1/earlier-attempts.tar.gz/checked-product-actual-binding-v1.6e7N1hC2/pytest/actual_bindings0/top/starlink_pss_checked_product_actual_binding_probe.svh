// Additive actual-preparation seam probes, using the FROZEN controller actor.
// Not vendor FFT, not changed actual acceptance, and not a runtime edit.
// Injected immediately inside the existing hazards initial block. The old
// bench is restored byte-for-byte by removing this exact include expansion.
      if(kind>=60 && kind<=63)begin
        if(kind==62)wait(dut.state==dut.VERIFY_LEASE && dut.held_phase);
        else wait(dut.state==dut.VERIFY_LEASE && !dut.held_phase);
        @(negedge fft_clk);
        if(dut.input_job_start || dut.config_valid || dut.product_bank_read_ready ||
           dut.preflight_events_now || !dut.preparation_valid)
          $fatal(1,"ACTUAL_BINDING_PROBE_NOT_CLEAN_PREFLIGHT kind=%0d",kind);
        case(kind)
          60:force dut.product_bank_ready=1'b0;
          61:force dut.product_reservation=1'b0;
          62:force dut.product_bank_position=9'd7;
          63:force dut.source_position=9'd7;
        endcase
        #0.001;
        $display("ACTUAL_BINDING_PROBE kind=%0d phase=%b ready=%b reservation=%b valid=%b position=%0d bound=%b start_binding=%b current=%h input_start=%b config=%b core_take=%b actor_only=1",
          kind,dut.held_phase,dut.product_bank_ready,dut.product_reservation,
          dut.preflight_valid,dut.preflight_position,dut.product_bound_receipt,
          dut.product_start_binding,dut.preflight_events_now,dut.input_job_start,
          dut.config_valid,dut.checked_product_bank.core_take);
        // These are independently declared source-level expectations, not
        // changes to the immutable original actual test's single-bit masks.
        if((kind==60 && (dut.product_bank_ready!==1'b0 || dut.product_reservation!==1'b1 || dut.preflight_events_now!==6'h00)) ||
           (kind==61 && (dut.product_bank_ready!==1'b1 || dut.product_reservation!==1'b0 || dut.preflight_events_now!==6'h10)) ||
           (kind==62 && (dut.preflight_position!==9'd7 || dut.product_start_binding!==1'b0 || dut.preflight_events_now!==6'h0a)) ||
           (kind==63 && (dut.preflight_position!==9'd7 || dut.preflight_events_now!==6'h02)))
          $fatal(1,"ACTUAL_BINDING_PROBE_SOURCE_EXPECTATION_CHANGED kind=%0d",kind);
        if(dut.input_job_start || dut.config_valid || dut.checked_product_bank.core_take)
          $fatal(1,"ACTUAL_BINDING_PROBE_EARLY_PUBLIC_ACTION kind=%0d",kind);
        if($test$plusargs("REQUIRE_OLD_INTERFACE"))begin
          if(kind==60 && dut.preflight_events_now!==6'h10)
            $fatal(1,"ACTUAL_BINDING_OLD_READY_RESERVATION_CONTRACT_DIFFERS");
          if(kind==62 && dut.preflight_events_now!==6'h02)
            $fatal(1,"ACTUAL_BINDING_OLD_SINGLE_FRAMING_MASK_DIFFERS");
        end
        $display("ACTUAL_BINDING_PROBE_PASS kind=%0d current=%h no_old_actual_scope_claim=1 actor_only=1",kind,dut.preflight_events_now);
        $finish;
      end
