// Real P1 controller/guards/joiner/ROM/product/banks, controlled identity actor.
// This is NOT actual FFT numerics, RF sensitivity, realtime capacity or timing.
`timescale 1ns/1ps
module tb_starlink_pss_checked_product_top #(parameter integer ENABLED=1, RESET_REFERENCE_PURGE=1);
  reg clk=0,fft_clk=0,resetn=0,fft_resetn=0,slow_clock_enable=1,fast_clock_enable=1;
  // Reset-only secondary oracle receives a DISTINCT held-reset provider.
  // Candidate raw resets/inputs/expected tuples are never changed by this.
  reg reference_extra_resetn=1;
  wire reference_fft_resetn=fft_resetn && reference_extra_resetn;
  always #5 if(slow_clock_enable)clk=~clk;
  always #2.857 if(fast_clock_enable)fft_clk=~fft_clk;
  reg input_valid=0,input_last=0,output_ready=1;
  reg [35:0] input_data=0;
  reg [8:0] input_position=0;
  reg [63:0] input_block_start=0;
  wire [1:0] input_ready,output_valid,output_last,fault;
  wire [35:0] output_data0,output_data1;
  wire [8:0] output_position0,output_position1;
  wire [74:0] output_metadata0,output_metadata1;
`define PARAMS .REGISTERED_SCHEDULING(1),.DISTRIBUTED_FAST_FAULT(1),.PER_CAUSE_FAULT_CDC(1), \
    .PRIVATE_NEXT_START_SCRATCH(1),.PRIVATE_ROM_READ_AHEAD(1),.PRIVATE_BLOCK_METADATA_READ_AHEAD(1), \
    .PRODUCER_LOCAL_FINAL_FENCE(1)
`define PORTS(I) .clk(clk),.resetn(resetn),.fft_clk(fft_clk),.fft_resetn(I==0 ? reference_fft_resetn : fft_resetn), \
    .input_valid(input_valid),.input_ready(input_ready[I]),.input_data(input_data), \
    .input_position(input_position),.input_last(input_last),.input_block_start(input_block_start), \
    .output_valid(output_valid[I]),.output_ready(output_ready),.output_data(output_data``I), \
    .output_position(output_position``I),.output_last(output_last[I]),.output_metadata(output_metadata``I),.fault(fault[I])
  starlink_pss_fft_bank_owned_product_fence #(`PARAMS) reference_top (`PORTS(0));
  starlink_pss_fft_bank_owned_checked_product #(`PARAMS,.CHECKED_PRODUCT_BANK(ENABLED)) dut (`PORTS(1));
`undef PARAMS
`undef PORTS
  reg [120:0] trace0[0:4095],trace1[0:4095];
  reg [35:0] independently_expected_payload[0:511];
  reg [35:0] independently_expected_fresh_payload[0:511];
  initial $readmemh("actor_expected_product.mem",independently_expected_payload);
  initial $readmemh("actor_fresh_expected_product.mem",independently_expected_fresh_payload);
  reg [63:0] independently_expected_start;
  integer count0=0,count1=0,compared=0,fast_cycles=0,kind=0,bit_index=0,target=0;
  integer starts=0,acknowledgments=0,seals=0,publications=0,core_beats=0,releases=0;
  integer start_cycle=-1,ack_cycle=-1,first_inverse=-1,last_inverse=-1;
  reg [74:0] changed_head;
  reg [69:0] changed_product;
  reg [1:0] changed_lease;
  integer fence_cycle=0;
  integer prejoin_held_edges=0;
  reg fast_rejoined=0;
  reg raw_corruption=0;
  integer forward_start_cycle=0,product_final_cycle=0,seal_cycle=0,publish_cycle=0;
  integer inverse_start_cycle=0,job_first_inverse=0,job_last_inverse=0;
  integer reference_tick=0,reference_forward=0,reference_final=0,reference_inverse=0,reference_first=0,reference_job=0;
  always @(posedge fft_clk)begin
    reference_tick=reference_tick+1;
    if(reference_top.input_job_start && !reference_top.held_phase)reference_forward=reference_tick;
    if(reference_top.product_valid && reference_top.product_bank_ready && !reference_top.fast_fault && reference_top.product_last)
      reference_final=reference_tick;
    if(reference_top.input_job_start && reference_top.held_phase)reference_inverse=reference_tick;
    if(reference_top.certified_input_beat && reference_top.held_phase)begin
      if(reference_top.product_bank_position==0)reference_first=reference_tick;
      if(reference_top.product_bank_position==511)begin
        reference_job=reference_job+1;
        $display("CHECKED_TOP_REFERENCE_LATENCY job=%0d forward_start=%0d product_final=%0d inverse_start=%0d core_first=%0d core_last=%0d",reference_job,reference_forward,reference_final,reference_inverse,reference_first,reference_tick);
      end
    end
  end
  always @(posedge clk)if(resetn && fft_resetn)begin
    if(output_valid[0] && output_ready)begin
      trace0[count0]={output_metadata0,output_last[0],output_position0,output_data0};count0=count0+1;
    end
    if(output_valid[1] && output_ready)begin
      independently_expected_start = kind>=9 ? 64'd447 : (count1/512)*64'd447;
      if({output_metadata1,output_last[1],output_position1,output_data1} !==
          {1'b1,independently_expected_start,10'b0,(count1%512==511),9'(count1%512),
           (kind==19 ? independently_expected_fresh_payload[count1%512] : independently_expected_payload[count1%512])})
        $fatal(1,"CHECKED_TOP_INDEPENDENT_ACTOR_TUPLE_CHANGED index=%0d",count1);
      trace1[count1]={output_metadata1,output_last[1],output_position1,output_data1};count1=count1+1;
    end
    while(compared<count0 && compared<count1)begin
      if(trace0[compared]!==trace1[compared])$fatal(1,"CHECKED_TOP_ACCEPTED_OUTPUT_CHANGED index=%0d reference=%h candidate=%h ref_descriptor=%h candidate_descriptor=%h",compared,trace0[compared],trace1[compared],reference_top.engine_metadata,dut.engine_metadata);
      compared=compared+1;
    end
  end
  always @(posedge fft_clk)begin
    fast_cycles=fast_cycles+1;
    if(fast_cycles>30000)$fatal(1,"CHECKED_TOP_WATCHDOG state=%0d fault=%b ref_state=%0d ref_input=%h ref_result=%h ref_preflight=%h candidate_count=%0d reference_count=%0d",dut.state,fault,reference_top.state,reference_top.input_guard.fault_reasons,reference_top.result_guard.fault_reasons,reference_top.epoch_preflight_reasons,count1,count0);
    if(resetn && fft_resetn)begin
      if(dut.input_job_start)begin starts=starts+1;start_cycle=fast_cycles;end
      if(kind==0 && (dut.fast_fault || reference_top.fast_fault))
        $fatal(1,"CHECKED_TOP_HEALTHY_FAULT state=%0d input=%h result=%h preflight=%h",dut.state,
          dut.input_guard.fault_reasons,dut.result_guard.fault_reasons,dut.epoch_preflight_reasons);
    end
  end
  generate if(ENABLED)begin : monitor
    integer tick=0;
    always @(posedge fft_clk)begin
      tick=tick+1;
      if(dut.fast_running)begin
      if(dut.checked_product_bank.private_take !==
         (dut.product_valid === 1'b1 && (dut.product_bank_ready && !dut.fast_fault) === 1'b1))
        $fatal(1,"CHECKED_TOP_ACTUAL_PRODUCT_HANDSHAKE_CHANGED");
      if(dut.checked_product_bank.core_take !== (dut.certified_input_beat && dut.held_phase))
        $fatal(1,"CHECKED_TOP_CORE_CERTIFICATE_CHANGED");
      if(dut.checked_product_bank.actual_handoff)begin
        acknowledgments=acknowledgments+1;ack_cycle=tick;
        if(!dut.checked_product_bank.ack_binding || !dut.product_guard_ack_event)
          $fatal(1,"CHECKED_TOP_UNBOUND_ACK");
      end
      if(dut.input_job_start && !dut.held_phase)forward_start_cycle=tick;
      if(dut.input_job_start && dut.held_phase)inverse_start_cycle=tick;
      if(dut.checked_product_bank.private_take && dut.product_last)product_final_cycle=tick;
      if(dut.checked_product_bank.seal)begin seals=seals+1;seal_cycle=tick;end
      if(dut.checked_product_bank.publication)begin publications=publications+1;publish_cycle=tick;end
      if(dut.job_accept && !dut.next_inverse && dut.checked_product_bank.issuer_events[0])
        $fatal(1,"CHECKED_TOP_LEGAL_FORWARD_ADMISSION_REJECTED");
      if(dut.return_commit_valid && dut.result_destination_ready && !dut.next_inverse && dut.checked_product_bank.issuer_events[1])
        $fatal(1,"CHECKED_TOP_REAL_GUARD_COMPLETION_REJECTED");
      if(dut.certified_input_beat && dut.held_phase)begin
        core_beats=core_beats+1;if(first_inverse<0)first_inverse=fast_cycles;last_inverse=fast_cycles;
        if(dut.product_bank_position==0)job_first_inverse=tick;
        job_last_inverse=tick;
        if(raw_corruption && dut.product_bank_position>=target)
          $fatal(1,"CHECKED_TOP_BAD_RAW_TOKEN_DELIVERED");
      end
      if(dut.checked_product_bank.lease_release)begin
        releases=releases+1;
        if(!dut.checked_input_complete || !dut.checked_product_bank.adapter.reader.drained)
          $fatal(1,"CHECKED_TOP_EARLY_LEASE_RELEASE");
        $display("CHECKED_TOP_LATENCY job=%0d forward_start=%0d product_final=%0d seal=%0d publication=%0d ack=%0d inverse_start=%0d core_first=%0d core_last=%0d release=%0d",releases,forward_start_cycle,product_final_cycle,seal_cycle,publish_cycle,ack_cycle,inverse_start_cycle,job_first_inverse,job_last_inverse,tick);
      end
      if(dut.input_job_start && dut.held_phase && !dut.product_start_binding)
        $fatal(1,"CHECKED_TOP_UNBOUND_START");
    end
    end
  end endgenerate
  initial begin
    if(!$value$plusargs("CASE=%d",kind))kind=0;
    if(!$value$plusargs("BIT=%d",bit_index))bit_index=0;
    if(!$value$plusargs("TARGET=%d",target))target=0;
    repeat(8)@(negedge clk);resetn=1;fft_resetn=1;
    for(integer job=0;job<(kind==0 ? 4 : 1);job=job+1)begin
      wait(input_ready===2'b11);@(negedge clk);
      input_block_start=job*447;
      for(integer n=0;n<512;n=n+1)begin
        input_valid=1;input_position=n;input_last=n==511;
        input_data={18'(n%17-8),18'(n%23-11)};
        @(negedge clk);
      end
      input_valid=0;input_last=0;
    end
    if(kind!=0)wait(1'b0); // Additive negative epochs own their terminal only.
    wait(compared==2048);repeat(150)@(negedge clk);
    if(fault || count0!=2048 || count1!=2048 || starts!=8)
      $fatal(1,"CHECKED_TOP_COMPLETION_COUNTS");
    if(ENABLED && (acknowledgments!=4 || seals!=4 || publications!=4 || releases!=4 || core_beats!=2048))
      $fatal(1,"CHECKED_TOP_OWNERSHIP_COUNTS");
    $display("CHECKED_PRODUCT_TOP_CONTROL_PASS enabled=%0d compared=%0d starts=%0d ack=%0d seals=%0d publications=%0d core=%0d releases=%0d control_actor_not_fft=1",ENABLED,compared,starts,acknowledgments,seals,publications,core_beats,releases);
    $finish;
  end
  generate if(ENABLED)begin : hazards
    task quarantine_no_inverse;
      begin
        repeat(8)@(negedge fft_clk);
        if(!dut.fast_fault || starts!=1 || core_beats!=0 || releases!=0 || publications>1 ||
            dut.input_job_start || dut.config_valid || dut.product_bank_read_ready || dut.output_valid)
          $fatal(1,"CHECKED_TOP_BINDING_ESCAPE kind=%0d bit=%0d target=%0d starts=%0d",kind,bit_index,target,starts);
        $display("CHECKED_TOP_REJECT_PASS kind=%0d bit=%0d target=%0d starts=%0d ack=%0d releases=%0d current=%0d control_actor_not_fft=1",kind,bit_index,target,starts,acknowledgments,releases,fence_cycle);
        $finish;
      end
    endtask
    task wait_boundary;
      begin
        case(target)
          0:wait(dut.product_handoff_capacity);
          1:wait(dut.state==dut.VERIFY_LEASE && dut.held_phase);
          2:wait(dut.state==dut.ARM_JOB && dut.held_phase && !dut.admission_receipt);
          3:wait(dut.state==dut.ARM_JOB && dut.held_phase && dut.admission_receipt);
          4:wait(dut.input_job_start_private && dut.held_phase);
          5:wait(dut.completion_accept && !dut.next_inverse);
          6:wait(dut.completion_receipt && !dut.next_inverse);
          7:wait(dut.checked_product_bank.seal);
          8:wait(dut.checked_product_bank.publication);
          9:wait(dut.product_valid && dut.product_last);
          default:$fatal(1,"CHECKED_TOP_BAD_BOUNDARY");
        endcase
        @(negedge fft_clk);
        if(core_beats || starts!=1)$fatal(1,"CHECKED_TOP_BOUNDARY_LATE");
      end
    endtask
    initial begin
      wait(resetn && fft_resetn);
      if(kind==1)begin
        wait(dut.product_valid && dut.product_position==target);@(negedge fft_clk);
        force dut.product_bank_ready=1'b0;
        repeat(3)begin
          #0.001;
          if(dut.checked_product_bank.private_take || dut.product.output_ready)
            $fatal(1,"CHECKED_TOP_FORCED_READY_TAKE");
          @(negedge fft_clk);
        end
        release dut.product_bank_ready;
        if(target==511)begin
          wait(compared==512);repeat(20)@(negedge fft_clk);
          if(fault || starts!=2 || acknowledgments!=1 || releases!=1)
            $fatal(1,"CHECKED_TOP_FINAL_READY_RECOVERY");
          $display("CHECKED_TOP_READY_PASS target=%0d compared=%0d outcome=complete control_actor_not_fft=1",target,compared);
          $finish;
        end else begin
          repeat(20)@(negedge fft_clk);
          if(!dut.fast_fault || publications || releases || core_beats)
            $fatal(1,"CHECKED_TOP_INTERIOR_READY_QUARANTINE");
          $display("CHECKED_TOP_READY_PASS target=%0d compared=%0d outcome=quarantine control_actor_not_fft=1",target,compared);
          $finish;
        end
      end
// Additive actual-preparation seam probes, using the FROZEN controller actor.
// Not vendor FFT, not changed actual acceptance, and not a runtime edit.
// Injected immediately inside the existing hazards initial block. The old
// bench is restored byte-for-byte by removing this exact include expansion.
      if(kind==65)begin
        wait(dut.state==dut.ACK_DRAIN && !dut.result_busy &&
             dut.forward_handoff_ack && !dut.any_fast_fault);
        #0.001;
        $display("ACTUAL_BINDING_ACK_CAPACITY ready=%b capacity=%b receipt=%b guard_busy=%b actual_ack=%b state=%0d actor_only=1",
          dut.result_destination_ready,dut.product_handoff_capacity,dut.forward_handoff_ack,
          dut.result_busy,dut.product_guard_ack_event,dut.state);
        if(dut.result_destination_ready!==1'b0 || dut.product_handoff_capacity!==1'b0 ||
           dut.forward_handoff_ack!==1'b1 || dut.result_busy!==1'b0 ||
           dut.product_guard_ack_event!==1'b0 || dut.state!=dut.ACK_DRAIN ||
           !dut.checked_product_bank.adapter.published_reference ||
           !dut.checked_product_bank.adapter.reader_reference || dut.input_job_start)
          $fatal(1,"ACTUAL_BINDING_ACK_CAPACITY_SOURCE_CHANGED");
        if($test$plusargs("REQUIRE_OLD_INTERFACE") &&
           dut.result_destination_ready!==dut.forward_handoff_ack)
          $fatal(1,"ACTUAL_BINDING_OLD_DRAIN_READY_EQUALS_RECEIPT_DIFFERS");
        $display("ACTUAL_BINDING_ACK_CAPACITY_PASS ready=0 capacity=0 receipt=1 guard_busy=0 actual_ack=0 actor_only=1");
        $finish;
      end
      if(kind>=60 && kind<=64)begin
        if(kind==62 || kind==64)wait(dut.state==dut.VERIFY_LEASE && dut.held_phase);
        else wait(dut.state==dut.VERIFY_LEASE && !dut.held_phase);
        @(negedge fft_clk);
        if(dut.input_job_start || dut.config_valid || dut.product_bank_read_ready ||
           dut.preflight_events_now || !dut.preparation_valid)
          $fatal(1,"ACTUAL_BINDING_PROBE_NOT_CLEAN_PREFLIGHT kind=%0d",kind);
        case(kind)
          60:force dut.product_bank_ready=1'b0;
          61:force dut.product_reservation=1'b0;
          62,64:begin
            changed_lease=dut.checked_product_bank.adapter.lease_reference;
            force dut.product_bank_position=9'd7;
          end
          63:force dut.source_position=9'd7;
        endcase
        #0.001;
        $display("ACTUAL_BINDING_PROBE kind=%0d phase=%b ready=%b reservation=%b valid=%b position=%0d bound=%b start_binding=%b current=%h input_start=%b config=%b core_take=%b actor_only=1",
          kind,dut.held_phase,dut.product_bank_ready,dut.product_reservation,
          dut.preflight_valid,dut.preflight_position,dut.product_bound_receipt,
          dut.product_start_binding,dut.preflight_events_now,dut.input_job_start,
          dut.config_valid,dut.checked_product_bank.core_take);
        // These are independently declared source-level expectations, not
        // changes to the immutable original actual test's single-bit masks.
        if((kind==60 && (dut.product_bank_ready!==1'b0 || dut.product_reservation!==1'b1 || dut.preflight_events_now!==6'h00)) ||
           (kind==61 && (dut.product_bank_ready!==1'b1 || dut.product_reservation!==1'b0 || dut.preflight_events_now!==6'h10)) ||
           ((kind==62 || kind==64) && (dut.preflight_position!==9'd7 || dut.product_start_binding!==1'b0 || dut.preflight_events_now!==6'h0a)) ||
           (kind==63 && (dut.preflight_position!==9'd7 || dut.preflight_events_now!==6'h02)))
          $fatal(1,"ACTUAL_BINDING_PROBE_SOURCE_EXPECTATION_CHANGED kind=%0d",kind);
        if(dut.input_job_start || dut.config_valid || dut.checked_product_bank.core_take)
          $fatal(1,"ACTUAL_BINDING_PROBE_EARLY_PUBLIC_ACTION kind=%0d",kind);
        if(kind==64)begin
          @(negedge fft_clk);release dut.product_bank_position;
          repeat(8)@(negedge fft_clk);
          $display("ACTUAL_BINDING_RETAINED_OWNER live_valid=%b published=%b reader=%b reader_owned=%b lease=%h original_lease=%h consumed=%0d release=%b start=%b state=%0d actor_only=1",
            dut.product_bank_valid,dut.checked_product_bank.adapter.published_reference,
            dut.checked_product_bank.adapter.reader_reference,dut.checked_product_bank.adapter.reader.owned,
            dut.checked_product_bank.adapter.lease_reference,changed_lease,
            dut.checked_product_bank.adapter.reader.consumed,dut.checked_product_bank.lease_release,
            dut.input_job_start,dut.state);
          if(dut.product_bank_valid!==1'b0 || dut.checked_product_bank.adapter.published_reference!==1'b1 ||
             dut.checked_product_bank.adapter.reader_reference!==1'b1 || dut.checked_product_bank.adapter.reader.owned!==1'b1 ||
             dut.checked_product_bank.adapter.lease_reference!==changed_lease ||
             dut.checked_product_bank.adapter.reader.consumed!==10'd0 ||
             dut.checked_product_bank.lease_release || dut.input_job_start || dut.config_valid ||
             dut.checked_product_bank.core_take || !dut.fast_fault || dut.state!=dut.QUARANTINE)
            $fatal(1,"ACTUAL_BINDING_RETAINED_OWNER_CHANGED");
          if($test$plusargs("REQUIRE_OLD_INTERFACE") && !dut.product_bank_valid)
            $fatal(1,"ACTUAL_BINDING_OLD_LIVE_VALID_AS_OWNER_DIFFERS");
          $display("ACTUAL_BINDING_RETAINED_OWNER_PASS live_valid=0 published=1 reader=1 consumed=0 released=0 actor_only=1");
          $finish;
        end
        if($test$plusargs("REQUIRE_OLD_INTERFACE"))begin
          if(kind==60 && dut.preflight_events_now!==6'h10)
            $fatal(1,"ACTUAL_BINDING_OLD_READY_RESERVATION_CONTRACT_DIFFERS");
          if(kind==62 && dut.preflight_events_now!==6'h02)
            $fatal(1,"ACTUAL_BINDING_OLD_SINGLE_FRAMING_MASK_DIFFERS");
        end
        $display("ACTUAL_BINDING_PROBE_PASS kind=%0d current=%h no_old_actual_scope_claim=1 actor_only=1",kind,dut.preflight_events_now);
        $finish;
      end
      if(kind==2 || kind==3 || kind==4 || kind==11 || kind==13 || kind==14)begin
        wait_boundary();
        if(kind==2 || kind==13 || kind==14)begin
          changed_head=dut.product_head_metadata ^ (75'b1<<bit_index);
          if(kind==13)changed_head[bit_index]=1'bx;
          if(kind==14)changed_head[bit_index]=1'bz;
          force dut.product_head_metadata=changed_head;
        end else if(kind==3)begin
          changed_lease=dut.product_head_lease ^ (2'b1<<bit_index);
          force dut.product_head_lease=changed_lease;
        end else if(kind==4)force dut.checked_product_bank.bound_receipt=1'b0;
        else force dut.product_head_owned_good=1'b0;
        #0.001;
        if(target==0 && (dut.checked_product_bank.actual_handoff || dut.product_guard_ack_event))
          $fatal(1,"CHECKED_TOP_CURRENT_UNBOUND_ACK");
        if(target==4 && dut.input_job_start)$fatal(1,"CHECKED_TOP_CURRENT_UNBOUND_START");
        fence_cycle=1;
        quarantine_no_inverse();
      end
      if(kind==5)begin
        wait_boundary();
        case(bit_index)
          0:force dut.core_output_valid=1'b1;
          1:force dut.core_status_valid=1'b1;
          2:force dut.event_frame=1'b1;
          3:force dut.certified_input_beat=1'b1;
          4:force dut.certified_input_complete=1'b1;
          5:force dut.event_input_halt=1'b1;
          6:force dut.product_overflow=1'b1;
          7:force dut.source_fault_fast=2'b11;
          8:force dut.input_guard_fault=1'b1;
          9:force dut.input_fault_now=1'b1;
          10:force dut.duplicate_start_fault_now=1'b1;
          default:$fatal(1,"CHECKED_TOP_BAD_CURRENT_CAUSE");
        endcase
        #0.001;
        if(dut.product_guard_ack_event || dut.checked_product_bank.actual_handoff ||
            dut.checked_product_bank.publication || dut.checked_product_bank.lease_release ||
            dut.return_commit_valid)
          $fatal(1,"CHECKED_TOP_CURRENT_RAW_ESCAPE");
        fence_cycle=1;
        quarantine_no_inverse();
      end
      if(kind==6)begin
        wait(dut.checked_product_bank.adapter.bank_valid && dut.checked_product_bank.adapter.bank_position==target);
        @(negedge fft_clk);
        if(target==3 && dut.checked_product_bank.adapter.bank_ready)
          $fatal(1,"CHECKED_TOP_RAW_STALL_NOT_REACHED");
        changed_head=dut.checked_product_bank.adapter.bank_metadata ^ (75'b1<<bit_index);
        force dut.checked_product_bank.adapter.bank_metadata=changed_head;
        raw_corruption=1;
        repeat(10)@(negedge fft_clk);
        if(!dut.fast_fault || !dut.checked_product_bank.reader_reasons[2] || releases ||
           dut.output_valid || dut.checked_product_bank.core_take || core_beats>target)
          $fatal(1,"CHECKED_TOP_RAW_READER_ESCAPE bit=%0d target=%0d core=%0d",bit_index,target,core_beats);
        $display("CHECKED_TOP_RAW_READ_PASS bit=%0d target=%0d core=%0d reason=%h control_actor_not_fft=1",bit_index,target,core_beats,dut.checked_product_bank.reader_reasons);
        $finish;
      end
      if(kind==7 || kind==8)begin
        wait(dut.product_valid && dut.product_position==target);@(negedge fft_clk);
        if(kind==7)begin
          changed_product=dut.checked_product_bank.adapter.product_metadata ^ (70'b1<<bit_index);
          force dut.checked_product_bank.adapter.product_metadata=changed_product;
        end else if(bit_index==0)force dut.checked_product_bank.adapter.product_position=9'd12;
        else if(target==511)force dut.checked_product_bank.adapter.product_last=1'b0;
        else force dut.checked_product_bank.adapter.product_last=1'b1;
        repeat(12)@(negedge fft_clk);
        if(!dut.fast_fault || publications || acknowledgments || releases || core_beats ||
          dut.return_commit_valid || dut.checked_product_bank.publication)
          $fatal(1,"CHECKED_TOP_BAD_PRODUCER_PUBLICATION");
        if(kind==8 && target==37 && bit_index==1 && dut.checked_product_bank.adapter.forward_completion)
          $fatal(1,"CHECKED_TOP_EARLY_LAST_FALSE_COMPLETION");
        $display("CHECKED_TOP_RAW_PRODUCT_PASS kind=%0d bit=%0d target=%0d bank_reason=%h issuer_reason=%h control_actor_not_fft=1",kind,bit_index,target,dut.checked_product_bank.bank_reasons,dut.checked_product_bank.issuer_reasons);
        $finish;
      end
      if(kind==9 || kind==10)begin
        case(target)
          0:wait(dut.source_bank.request_toggle);
          1:wait(dut.certified_input_beat && !dut.held_phase && dut.source_position==37);
          2:wait(dut.product_valid && dut.product_position==37);
          3:wait(dut.product_bound_receipt);
          4:wait(dut.certified_input_beat && dut.held_phase && dut.product_bank_position==37);
          default:$fatal(1,"CHECKED_TOP_BAD_RESET_PHASE");
        endcase
        @(negedge clk);
        if(kind==10)begin
          if(!dut.source_ready)$fatal(1,"CHECKED_TOP_POISON_WRITER_NOT_READY");
          input_valid=1;input_position=37;input_last=0;
          @(negedge clk);input_valid=0;
          if(!dut.source_fault)$fatal(1,"CHECKED_TOP_POISON_NOT_REACHED");
        end
        slow_clock_enable=0;
        if(RESET_REFERENCE_PURGE)reference_extra_resetn=0;
        if(bit_index==0)fft_resetn=0;else resetn=0;
        repeat(4)@(negedge fft_clk);
        resetn=1;fft_resetn=1;
        wait(dut.fast_running);
        repeat(8)begin
          @(negedge fft_clk);
          if(dut.source_epoch_open || dut.source_valid || dut.source_fault_fast ||
             dut.checked_product_bank.origin_valid || dut.product_bound_receipt ||
             dut.checked_product_bank.private_take || dut.checked_product_bank.publication ||
             dut.input_job_start || dut.config_valid || dut.product_bank_read_ready)
            $fatal(1,"CHECKED_TOP_PAUSED_SLOW_REOPENED kind=%0d reset=%0d target=%0d",kind,bit_index,target);
          if(kind==10 && !dut.source_fault)$fatal(1,"CHECKED_TOP_OLD_SOURCE_POISON_NOT_RETAINED");
        end
        slow_clock_enable=1;
        if(RESET_REFERENCE_PURGE)begin
          repeat(4)@(negedge clk);
          reference_extra_resetn=1;
        end
        wait(dut.source_epoch_open && dut.slow_running && input_ready===2'b11);
        @(negedge clk);
        count0=0;count1=0;compared=0;starts=0;acknowledgments=0;seals=0;publications=0;releases=0;core_beats=0;
        input_block_start=447;
        for(integer n=0;n<512;n=n+1)begin
          input_valid=1;input_position=n;input_last=n==511;input_data={18'(n%17-8),18'(n%23-11)};
          @(negedge clk);
        end
        input_valid=0;input_last=0;
        wait(compared==512);repeat(20)@(negedge clk);
        if(fault || starts!=2 || acknowledgments!=1 || releases!=1 || core_beats!=512)
          $fatal(1,"CHECKED_TOP_RESET_RECOVERY_FAILED");
        $display("CHECKED_TOP_RESET_PASS kind=%0d reset=%0d target=%0d paused_edges=8 compared=%0d starts=%0d ack=%0d releases=%0d independent_expected=512 secondary_reference_reset_provider=%0d control_actor_not_fft=1",kind,bit_index,target,compared,starts,acknowledgments,releases,RESET_REFERENCE_PURGE);
        $finish;
      end
      if(kind==12 || kind==15)begin
        wait(dut.product_valid && dut.product_position==target);@(negedge fft_clk);
        if(kind==12)begin
          if(bit_index==0)force dut.product_bank_ready=1'bx;
          else force dut.product_bank_ready=1'bz;
        end else begin
          force dut.product_bank_ready=1'b0;
          if(bit_index==0)force dut.product_valid=1'bx;
          else force dut.product_valid=1'bz;
        end
        #0.001;
        if(!dut.checked_product_bank.issuer_events[7] || !dut.external_fault_now ||
            dut.checked_product_bank.private_take || dut.checked_product_bank.publication)
          $fatal(1,"CHECKED_TOP_UNKNOWN_PRODUCT_CURRENT_ESCAPE");
        repeat(8)@(negedge fft_clk);
        if(!dut.fast_fault || !dut.checked_product_bank.issuer_reasons[7] || publications || acknowledgments || releases)
          $fatal(1,"CHECKED_TOP_UNKNOWN_PRODUCT_STICKY_ESCAPE");
        $display("CHECKED_TOP_UNKNOWN_PRODUCT_PASS kind=%0d value=%0d target=%0d current=1 sticky=1 control_actor_not_fft=1",kind,bit_index,target);
        $finish;
      end
      if(kind==17 || kind==18 || kind==19)begin
        // Forward activity, no inverse-output owner. The unchanged output CDC
        // is not claimed to solve arbitrary paused-fast published-output reset.
        wait(dut.product_valid && dut.product_position==37);@(negedge fft_clk);
        if(dut.next_inverse || dut.output_bank.request_toggle)
          $fatal(1,"CHECKED_TOP_FAST_PAUSE_WRONG_PHASE");
        fast_clock_enable=0;reference_extra_resetn=0;
        if(bit_index==0)fft_resetn=0;else resetn=0;
        repeat(4)@(negedge clk);resetn=1;fft_resetn=1;
        wait(input_ready[1]===1'b1);@(negedge clk);
        count0=0;count1=0;compared=0;starts=0;acknowledgments=0;seals=0;publications=0;releases=0;core_beats=0;
        input_block_start=447;
        for(integer n=0;n<512;n=n+1)begin
          if(!fast_rejoined && (dut.source_epoch_open || dut.source_valid || dut.checked_product_bank.publication || dut.output_valid))
            $fatal(1,"CHECKED_TOP_PREJOIN_SOURCE_ESCAPE");
          input_valid=1;input_position=n;input_last=n==511;input_data={18'(n%17-8),18'(n%23-11)};
          if(kind==19)begin
            input_data={18'(n%17+3064),18'(n%23-4107)};
            if(input_data==={18'(n%17-8),18'(n%23-11)})
              $fatal(1,"CHECKED_TOP_FRESH_PAYLOAD_NOT_DISTINCT");
          end
          if(input_ready[1]!==1'b1)begin
            if(kind==17)$fatal(1,"CHECKED_TOP_PREJOIN_SOURCE_NOT_ACCEPTED n=%0d req=%b ack_sync=%b fast_ack=%b write=%0d epoch=%b fault=%b",n,dut.source_bank.request_toggle,dut.source_bank.acknowledge_sync,dut.source_bank.acknowledge_toggle,dut.source_bank.write_position,dut.source_epoch_open,dut.source_fault);
            if(n!=2 || fast_rejoined || dut.source_bank.write_position!=2 ||
               dut.source_bank.request_toggle!==1'b0 || dut.source_bank.acknowledge_sync!==2'b11 ||
               dut.source_bank.acknowledge_toggle!==1'b1)
              $fatal(1,"CHECKED_TOP_PREJOIN_STALL_PREMISE_MISSING");
            repeat(8)begin
              @(negedge clk);prejoin_held_edges=prejoin_held_edges+1;
              if(input_ready[1]!==1'b0 || dut.source_bank.write_position!=2 ||
                 dut.source_bank.request_toggle || dut.source_fault || dut.source_valid ||
                 dut.source_epoch_open || dut.checked_product_bank.publication || dut.output_valid ||
                 input_position!=2 || (kind!=19 && input_data!=={18'(2%17-8),18'(2%23-11)}) || input_block_start!=447)
                $fatal(1,"CHECKED_TOP_PREJOIN_HELD_PREFIX_CHANGED");
              if(kind==19 && input_data!=={18'(2%17+3064),18'(2%23-4107)})
                $fatal(1,"CHECKED_TOP_DISTINCT_HELD_PREFIX_CHANGED");
            end
            fast_clock_enable=1;fast_rejoined=1;
            wait(input_ready[1]===1'b1);
          end
          @(posedge clk);
          if(input_ready[1]!==1'b1)$fatal(1,"CHECKED_TOP_PREJOIN_RESUMED_ACCEPT_MISSING");
          @(negedge clk);
        end
        input_valid=0;input_last=0;
        if(!fast_rejoined || prejoin_held_edges!=8 || dut.source_fault)
          $fatal(1,"CHECKED_TOP_PREJOIN_RESUME_PREMISE_MISSING");
        wait(count1==512);repeat(20)@(negedge clk);
        if(dut.fault || starts!=2 || acknowledgments!=1 || releases!=1 || core_beats!=512 || count0)
          $fatal(1,"CHECKED_TOP_PREJOIN_RECOVERY_FAILED");
        $display("CHECKED_TOP_PREJOIN_HELD_PASS reset=%0d accepted_while_fast_paused=2 held_edges=%0d accepted_total=512 independent_expected=512 starts=%0d ack=%0d releases=%0d secondary_reference_held_reset=1 control_actor_not_fft=1",bit_index,prejoin_held_edges,starts,acknowledgments,releases);
        if(kind==19)$display("CHECKED_TOP_DISTINCT_PAYLOAD_PASS reset=%0d input_words_changed=512 expected_outputs_changed=512 independently_checked=%0d starts=%0d ack=%0d releases=%0d control_actor_not_fft=1",bit_index,count1,starts,acknowledgments,releases);
        $finish;
      end
    end
  end endgenerate
  `include "checked_product_default_observer.svh"

  localparam REGISTERED_SCHEDULING=1;
  wire [31:0] fast_cycle=fast_cycles;
  integer epoch=0,active_fixture=0;
  integer corrupt_observer=-1;
  reg [4:0] forward_exponents[0:0];
  initial forward_exponents[0]=0; // Declared identity-control actor, not FFT vectors.
  // This monitor calls the ACTUAL observer's unchanged retained-owner task
  // before the existing kind64 force; the continuous watcher owns the interval.
  initial if($test$plusargs("WATCH_RETAINED"))begin
    wait(dut.state==dut.VERIFY_LEASE && dut.held_phase);
    #0.001;checked_begin_retained_watch();
  end
  // Corrupt ONLY the independent observer's private evidence. The DUT and
  // original actor stimulus remain literal; each detector must reject it.
  initial if($value$plusargs("CORRUPT_OBSERVER=%d",corrupt_observer))begin
    case(corrupt_observer)
      0:begin wait(dut.product_handoff_capacity);@(negedge fft_clk);
        checked_origin_lease=checked_origin_lease^2'b01;end
      1:begin wait(dut.input_job_start_private && dut.held_phase);@(negedge fft_clk);
        checked_bound_receipt=0;end
      2:begin wait(dut.checked_product_bank.core_take && dut.product_bank_position==37);
        @(negedge fft_clk);checked_raw_word[37]=checked_raw_word[37]^36'b1;end
      3:begin wait(dut.checked_product_bank.lease_release);@(negedge fft_clk);
        checked_core_index=511;end
      4:begin wait(checked_retained_watch && dut.fast_fault);@(negedge fft_clk);
        checked_retained_lease=checked_retained_lease^2'b01;end
      5:begin wait(dut.state==dut.ACK_DRAIN && !dut.result_busy && dut.forward_handoff_ack);
        #0.001;checked_bound_receipt=0;end
      default:$fatal(1,"OBSERVER_BAD_CORRUPTION_PROFILE");
    endcase
  end
  initial if(kind==66)begin
    wait(dut.checked_product_bank.adapter.reader.raw_valid &&
         dut.checked_product_bank.adapter.reader.raw_position==37);
    @(negedge fft_clk);
    if(target==0)force dut.core_input_ready=0;
    else force dut.core_input_ready=1;
    if(bit_index==0)force dut.checked_product_bank.adapter.reader.raw_metadata=75'h123;
    if(bit_index==1)force dut.checked_product_bank.adapter.reader.raw_position=9'd7;
    if(bit_index==2)force dut.checked_product_bank.adapter.reader.raw_last=1;
    repeat(4)@(negedge fft_clk);
    if(dut.checked_product_bank.reader_reasons[3:0] !==
       (bit_index==0 ? 4'h4 : bit_index==1 ? 4'h1 : 4'h2) ||
       dut.checked_product_bank.core_take || dut.return_commit_valid ||
       checked_core_index>37 || checked_raw_bad_offers<=0)
      $fatal(1,"OBSERVER_RAW_OFFER_BOUNDARY_ESCAPED");
    $display("CHECKED_OBSERVER_RAW_OFFER_PASS kind=%0d ready=%0d reason=%h core=%0d bad_offers=%0d actor_only=1",
      bit_index,target,dut.checked_product_bank.reader_reasons[3:0],checked_core_index,checked_raw_bad_offers);
    $finish;
  end
  final $display("CHECKED_OBSERVER_ACTOR_END kind=%0d jobs=%0d acks=%0d starts=%0d raw_bad=%0d releases=%0d capacity=%0d retained=%0d guard=%0d pre=%0d post=%0d actor_only=1",
    kind,checked_jobs,checked_acks,checked_starts,checked_raw_bad_offers,
    checked_releases,checked_capacity_receipts,checked_retained_checks,forward_checks,
    checked_pre,checked_post);
  // BEGIN FORWARD_RETIREMENT_SHADOW: additive frozen old full guard/chain.
  wire forward_old_valid, forward_old_private;
  wire [31:0] forward_checks, forward_cycles, forward_current, forward_sticky;
  starlink_pss_forward_retirement_shadow #(.ENABLED(REGISTERED_SCHEDULING),
    .COMPLETED(1), .PREFLIGHT(REGISTERED_SCHEDULING)) forward_shadow (
    .clk(fft_clk), .resetn(dut.fast_running), .job_valid(dut.job_valid),
    .job_descriptor(dut.result_guard.job_descriptor),
    .input_bank_reserved(dut.result_guard.input_bank_reserved),
    .output_bank_reserved(dut.result_guard.output_bank_reserved),
    .certified_input_beat(dut.certified_input_beat), .certified_input_complete(dut.certified_input_complete),
    .final_fence_certified(dut.final_fence), .external_fault_now(dut.external_fault_now),
    .phase_input_fault_now(1'b0), .completed_input_certified(dut.checked_input_complete),
    .completed_input_fault_now(dut.completed_input_fault_now),
    .preflight_fault_evidence_now(dut.preparation_fault_now),
    .core_event_frame_started(dut.event_frame), .core_output_tdata(dut.core_output_data),
    .core_output_tuser(dut.core_output_user), .core_output_tvalid(dut.core_output_valid),
    .core_output_tlast(dut.core_output_last), .core_status_tdata(dut.core_status_data),
    .core_status_tvalid(dut.core_status_valid), .mailbox_input_ready(dut.result_destination_ready),
    .mailbox_input_fault(dut.output_bank_fault || dut.output_bank_framing_fault_now),
    .inverse_phase(dut.next_inverse), .forward_mailbox_fault(dut.output_bank_fault),
    .mailbox_current_fault_now(dut.output_bank_framing_fault_now),
    .actual_public({dut.job_ready, dut.return_valid, dut.return_private_valid, dut.return_commit_valid,
      dut.return_data, dut.return_position, dut.return_last, dut.return_metadata,
      dut.result_busy, dut.result_commit, dut.result_fault, dut.result_guard.fault_reasons}),
    .actual_forward_valid(dut.forward_retirement_valid), .old_valid(forward_old_valid),
    .old_private_valid(forward_old_private), .checks(forward_checks), .forward_cycles(forward_cycles),
    .inverse_current_faults(forward_current), .sticky_forward_faults(forward_sticky)
  );
// Enabled actual-candidate observation contract. No DUT drives; no raw217 or
// cycle-CSV equivalence claim. Frozen old port-fed guard/ROM/arithmetic remain.
  integer checked_pre=0, checked_post=0, checked_jobs=0, checked_products=0;
  integer checked_seals=0, checked_publications=0, checked_acks=0, checked_starts=0;
  integer checked_raw_offers=0, checked_raw_takes=0, checked_raw_bad_offers=0;
  integer checked_core_takes=0, checked_releases=0, checked_resets=0;
  integer checked_current_vetoes=0, checked_purge_checks=0, checked_status_samples=0;
  integer checked_capacity_receipts=0, checked_retained_checks=0;
  integer checked_producer_index=0, checked_raw_index=0, checked_core_index=0;
  integer checked_forward_cycle=0, checked_product_final_cycle=0, checked_seal_cycle=0;
  integer checked_publication_cycle=0, checked_ack_cycle=0, checked_start_cycle=0;
  integer checked_first_core_cycle=0, checked_last_core_cycle=0;
  reg checked_origin_valid=0, checked_bound_receipt=0, checked_producer_bad=0;
  reg [1:0] checked_origin_lease=0;
  reg [69:0] checked_expected_product=0;
  reg checked_bad_word[0:511];
  reg [35:0] checked_raw_word[0:511];
  reg checked_slow_purge=0;
  reg checked_retained_watch=0;
  reg [1:0] checked_retained_lease=0;
  reg [1:0] checked_purge_fast=0;
  integer checked_ledger;
  initial begin
    if(dut.CHECKED_PRODUCT_BANK !== 1 || dut.input_guard.CHECKED_PRODUCT_BINDING !== 1 ||
       dut.input_guard.CHECK_INPUT_BLOCK_IDENTITY !== 1 ||
       dut.checked_product_bank.adapter.SEPARATE_PRODUCT_SEAMS !== 1)
      $fatal(1,"CHECKED_ACTUAL_BINDING_PARAMETERS_CHANGED");
    checked_ledger=$fopen("checked_product_ownership_trace.csv","w");
    $fdisplay(checked_ledger,"cycle,epoch,event,position,data,metadata,lease");
  end
  wire checked_common_resetn = resetn && fft_resetn;
  always @(posedge clk or negedge checked_common_resetn)
    if(!checked_common_resetn)checked_slow_purge<=0;
    else if(!dut.slow_running)checked_slow_purge<=1;
  always @(posedge fft_clk or negedge checked_common_resetn)
    if(!checked_common_resetn)checked_purge_fast<=0;
    else if(!dut.fast_running)checked_purge_fast<=0;
    else checked_purge_fast<={checked_purge_fast[0],checked_slow_purge};
  // Controller-origin evidence is independently captured from actual forward
  // admission. The candidate origin/head/expected copies cannot self-certify.
  wire checked_head_identity = checked_origin_valid &&
    dut.checked_product_bank.origin_valid === 1'b1 &&
    dut.product_origin_lease === checked_origin_lease &&
    dut.product_head_metadata === {5'b0,checked_expected_product} &&
    dut.product_head_lease === checked_origin_lease;
  wire checked_first_head = dut.product_bank_position === 9'd0 && dut.product_bank_last === 1'b0;
  wire checked_start_binding = checked_bound_receipt && dut.product_handoff_state_owned &&
    dut.product_head_owned_good && checked_head_identity && checked_first_head &&
    !dut.product_reader_token_fault && !dut.checked_product_bank.producer_verdict &&
    dut.held_phase === 1'b1 && dut.next_inverse === 1'b1 &&
    dut.engine_metadata === checked_expected_product;
  wire checked_old_guard_ack = dut.fast_running && forward_shadow.old_guard.awaiting_ack &&
    dut.result_destination_ready && !forward_shadow.old_guard.protocol_fault &&
    !forward_shadow.old_guard.idle_fault_now;
  task checked_record(input integer event_kind, input [8:0] position,
                      input [35:0] data, input [74:0] metadata, input [1:0] lease);
    $fdisplay(checked_ledger,"%0d,%0d,%0d,%0d,%h,%h,%h",fast_cycle,epoch,event_kind,position,data,metadata,lease);
  endtask
  task checked_begin_retained_watch;
    begin
      if(!dut.held_phase || !dut.checked_product_bank.adapter.published_reference ||
         !dut.checked_product_bank.adapter.reader_reference ||
         !dut.checked_product_bank.adapter.reader.owned ||
         dut.checked_product_bank.adapter.reader.consumed!=0)
        $fatal(1,"CHECKED_ACTUAL_RETAINED_WATCH_BAD_ENTRY");
      checked_retained_lease=dut.checked_product_bank.adapter.lease_reference;
      checked_retained_watch=1;
    end
  endtask
  task checked_retained_owner;
    begin
      if(!checked_retained_watch || !dut.checked_product_bank.adapter.published_reference ||
         !dut.checked_product_bank.adapter.reader_reference ||
         !dut.checked_product_bank.adapter.reader.owned || !dut.checked_product_bank.adapter.bank_published ||
         dut.checked_product_bank.adapter.lease_reference!==checked_retained_lease ||
         dut.checked_product_bank.bank_lease!==checked_retained_lease ||
         dut.checked_product_bank.adapter.reader.consumed!=0 ||
         dut.checked_product_bank.lease_release || dut.checked_product_bank.core_take ||
         dut.input_job_start || dut.config_valid)
        $fatal(1,"CHECKED_ACTUAL_RETAINED_LEASE_CONSUMED_OR_RELEASED");
      checked_retained_checks=checked_retained_checks+1;
    end
  endtask
  always @(posedge fft_clk or negedge fft_clk)begin
    #0.002;
    if(checked_retained_watch && dut.fast_running && dut.source_epoch_open)
      checked_retained_owner();
  end
  always @(posedge fft_clk)begin
    #0;
    checked_pre=checked_pre+1;
    // Also inspect the actually sampled pre-NBA boundary, so a take/release
    // pulse cannot disappear in the NBA update before the settled edge checks.
    if(checked_retained_watch && dut.fast_running && dut.source_epoch_open)
      checked_retained_owner();
    if(!dut.fast_running || !dut.source_epoch_open)begin
      checked_origin_valid=0;checked_bound_receipt=0;checked_producer_bad=0;
      checked_retained_watch=0;
      checked_producer_index=0;checked_raw_index=0;checked_core_index=0;
      for(integer i=0;i<512;i=i+1)begin checked_bad_word[i]=0;checked_raw_word[i]=0;end
      checked_resets=checked_resets+1;
    end else begin
      if(dut.product_guard_ack_event !== checked_old_guard_ack)
        $fatal(1,"CHECKED_ACTUAL_OLD_GUARD_ACK_EDGE_CHANGED");
      if(dut.state==dut.ACK_DRAIN && !dut.result_busy && !dut.any_fast_fault &&
         !dut.next_inverse && dut.forward_handoff_ack)begin
        if(dut.product_handoff_capacity || dut.result_destination_ready ||
           !checked_bound_receipt || !dut.product_handoff_state_owned)
          $fatal(1,"CHECKED_ACTUAL_CAPACITY_RECEIPT_OWNERSHIP_CHANGED");
        checked_capacity_receipts=checked_capacity_receipts+1;
      end
      if(dut.job_accept && !dut.next_inverse)begin
        checked_origin_lease=dut.checked_product_bank.bank_lease;
        checked_origin_valid=1;checked_bound_receipt=0;checked_producer_bad=0;
        checked_expected_product={1'b1,dut.engine_metadata[68:5],forward_exponents[active_fixture]};
        checked_producer_index=0;checked_raw_index=0;checked_core_index=0;
        for(integer i=0;i<512;i=i+1)begin checked_bad_word[i]=0;checked_raw_word[i]=0;end
        checked_jobs=checked_jobs+1;
      end
      if(dut.input_job_start && !dut.held_phase)checked_forward_cycle=fast_cycle;
      if(dut.core_status_valid===1'b1)checked_status_samples=checked_status_samples+1;
      if(dut.product_valid===1'b1)begin
        if(dut.checked_product_bank.adapter.product_metadata !== checked_expected_product ||
           dut.product_position !== checked_producer_index[8:0] ||
           dut.product_last !== (checked_producer_index==511))checked_producer_bad=1;
      end
      if(dut.checked_product_bank.private_take !==
         (dut.product_valid===1'b1 && (dut.product_bank_ready && !dut.fast_fault)===1'b1))
        $fatal(1,"CHECKED_ACTUAL_SAMPLED_PRODUCT_READY_CHANGED");
      if(dut.checked_product_bank.private_take)begin
        checked_products=checked_products+1;checked_producer_index=checked_producer_index+1;
        checked_record(1,dut.product_position,{dut.product_q,dut.product_i},
          {5'b0,dut.checked_product_bank.adapter.product_metadata},checked_origin_lease);
        if(dut.product_last)checked_product_final_cycle=fast_cycle;
      end
      if(dut.checked_product_bank.seal || dut.checked_product_bank.publication)begin
        if(checked_producer_bad || !checked_origin_valid || checked_producer_index!=512 ||
           !dut.forward_committed || dut.checked_product_bank.publication_current !== 8'b0 ||
           dut.checked_product_bank.independent_current !== 8'b0 ||
           dut.checked_product_bank.producer_verdict)
          $fatal(1,"CHECKED_ACTUAL_UNQUALIFIED_SEAL_PUBLICATION");
      end
      if(dut.checked_product_bank.seal)begin checked_seals=checked_seals+1;checked_seal_cycle=fast_cycle;end
      if(dut.checked_product_bank.publication)begin
        checked_publications=checked_publications+1;checked_publication_cycle=fast_cycle;
        checked_record(2,0,0,{5'b0,checked_expected_product},checked_origin_lease);
      end
      if(dut.checked_product_bank.adapter.reader.raw_valid===1'b1 &&
         dut.checked_product_bank.adapter.reader.owned)begin
        checked_raw_offers=checked_raw_offers+1;
        if(checked_raw_index>=512)$fatal(1,"CHECKED_ACTUAL_EXTRA_RAW_OFFER");
        if(dut.checked_product_bank.adapter.reader.raw_metadata !== {5'b0,checked_expected_product} ||
           dut.checked_product_bank.adapter.reader.raw_lease !== checked_origin_lease ||
           dut.checked_product_bank.adapter.reader.raw_position !== checked_raw_index[8:0] ||
           dut.checked_product_bank.adapter.reader.raw_last !== (checked_raw_index==511))begin
          checked_bad_word[checked_raw_index]=1;checked_raw_bad_offers=checked_raw_bad_offers+1;
        end
        if(dut.checked_product_bank.adapter.reader.raw_ready)begin
          checked_raw_word[checked_raw_index]=dut.checked_product_bank.adapter.reader.raw_data;
          checked_raw_index=checked_raw_index+1;checked_raw_takes=checked_raw_takes+1;
        end
      end
      if(dut.checked_product_bank.actual_handoff)begin
        if(!checked_old_guard_ack || !checked_head_identity || !checked_first_head ||
           !dut.checked_product_bank.head_valid || !dut.forward_handoff_identity)
          $fatal(1,"CHECKED_ACTUAL_UNBOUND_REAL_ACK");
        checked_bound_receipt=1;checked_acks=checked_acks+1;checked_ack_cycle=fast_cycle;
        checked_record(3,0,0,{5'b0,checked_expected_product},checked_origin_lease);
      end
      if(dut.input_job_start && dut.held_phase)begin
        if(!checked_start_binding)$fatal(1,"CHECKED_ACTUAL_UNBOUND_INVERSE_START");
        checked_starts=checked_starts+1;checked_start_cycle=fast_cycle;
        checked_bound_receipt=0;
      end
      if(dut.checked_product_bank.core_take !== (dut.certified_input_beat && dut.held_phase))
        $fatal(1,"CHECKED_ACTUAL_CORE_CERTIFICATE_DIVERGED");
      if(dut.checked_product_bank.core_take)begin
        if(checked_core_index>=512 || checked_core_index>=checked_raw_index ||
           checked_bad_word[checked_core_index] ||
           dut.product_bank_data !== checked_raw_word[checked_core_index] ||
           dut.product_bank_position !== checked_core_index[8:0] ||
           dut.product_bank_last !== (checked_core_index==511) ||
           dut.product_head_lease !== checked_origin_lease || !dut.product_head_owned_good ||
           dut.product_reader_token_fault)
          $fatal(1,"CHECKED_ACTUAL_BAD_OR_UNCHECKED_CORE_TOKEN");
        if(checked_core_index==0)checked_first_core_cycle=fast_cycle;
        checked_last_core_cycle=fast_cycle;
        checked_record(4,dut.product_bank_position,dut.product_bank_data,dut.product_head_metadata,dut.product_head_lease);
        checked_core_index=checked_core_index+1;checked_core_takes=checked_core_takes+1;
      end
      if(dut.checked_product_bank.lease_release)begin
        if(checked_core_index!=512 || checked_raw_index!=512 ||
           !dut.checked_input_complete || !dut.checked_product_bank.adapter.reader.drained)
          $fatal(1,"CHECKED_ACTUAL_PREMATURE_RELEASE");
        checked_releases=checked_releases+1;
        $display("CHECKED_ACTUAL_LATENCY epoch=%0d forward_start=%0d product_final=%0d seal=%0d publication=%0d ack=%0d inverse_start=%0d first_core=%0d last_core=%0d release=%0d",
          epoch,checked_forward_cycle,checked_product_final_cycle,checked_seal_cycle,checked_publication_cycle,
          checked_ack_cycle,checked_start_cycle,checked_first_core_cycle,checked_last_core_cycle,fast_cycle);
      end
      if(dut.any_fast_fault)checked_current_vetoes=checked_current_vetoes+1;
      if(dut.checked_product_bank.lease_release || dut.fast_fault || dut.result_fault ||
         dut.checked_product_bank.adapter_fault)begin checked_origin_valid=0;checked_bound_receipt=0;end
    end
    #0.001;#0;
    if(dut.source_epoch_open !== (dut.fast_running && checked_purge_fast[1]))
      $fatal(1,"CHECKED_ACTUAL_SOURCE_PURGE_RECURRENCE_CHANGED");
    checked_purge_checks=checked_purge_checks+1;checked_post=checked_post+1;
  end
  task checked_actual_verify_terminal;
    begin
      if(checked_pre<=0 || checked_post!=checked_pre || checked_jobs<=0 || checked_products<512 ||
         checked_seals<=0 || checked_publications<=0 || checked_acks<=0 || checked_starts<=0 ||
         checked_raw_offers<512 || checked_raw_takes<512 || checked_raw_bad_offers<=0 ||
         checked_core_takes<512 || checked_releases<=0 || checked_resets<=0 ||
         checked_current_vetoes<=0 || checked_status_samples<=0 || checked_purge_checks!=checked_post ||
         checked_capacity_receipts<=0 || checked_retained_checks<=0)
        $fatal(1,"CHECKED_ACTUAL_OWNERSHIP_COVERAGE_INCOMPLETE");
      $display("CHECKED_PRODUCT_ACTUAL_PASS enabled=1 pre=%0d post=%0d jobs=%0d products=%0d seals=%0d publications=%0d acks=%0d starts=%0d raw_offers=%0d raw_takes=%0d raw_bad_offers=%0d core_takes=%0d releases=%0d resets=%0d current_faults=%0d statuses=%0d purge_checks=%0d capacity_receipts=%0d retained_checks=%0d source=actual_ports_and_independent_origin changed_latency=1 raw217_claim=0",
        checked_pre,checked_post,checked_jobs,checked_products,checked_seals,checked_publications,
        checked_acks,checked_starts,checked_raw_offers,checked_raw_takes,checked_raw_bad_offers,
        checked_core_takes,checked_releases,checked_resets,checked_current_vetoes,checked_status_samples,checked_purge_checks,
        checked_capacity_receipts,checked_retained_checks);
      $fclose(checked_ledger);
    end
  endtask
endmodule
`timescale 1ns/1fs
// Frozen full old guard: no candidate forward predicates feed this witness.
module starlink_pss_forward_retirement_shadow #(
  parameter integer ENABLED = 1,
  parameter integer COMPLETED = 1,
  parameter integer PHASE_INPUT = 0,
  parameter integer PREFLIGHT = 0,
  parameter integer WATCHDOG = 8192
) (
  input wire clk, resetn, job_valid,
  input wire [69:0] job_descriptor,
  input wire input_bank_reserved, output_bank_reserved,
  input wire certified_input_beat, certified_input_complete, final_fence_certified,
  input wire external_fault_now, phase_input_fault_now,
  input wire completed_input_certified, completed_input_fault_now, preflight_fault_evidence_now,
  input wire core_event_frame_started,
  input wire [47:0] core_output_tdata,
  input wire [23:0] core_output_tuser,
  input wire core_output_tvalid, core_output_tlast,
  input wire [7:0] core_status_tdata,
  input wire core_status_tvalid, mailbox_input_ready, mailbox_input_fault,
  input wire inverse_phase, forward_mailbox_fault, mailbox_current_fault_now,
  input wire [135:0] actual_public,
  input wire actual_forward_valid,
  output wire old_valid, old_private_valid,
  output integer checks = 0,
  output integer forward_cycles = 0,
  output integer inverse_current_faults = 0,
  output integer sticky_forward_faults = 0
);
  wire old_ready, old_commit_valid, old_last, old_busy, old_commit, old_fault;
  wire [35:0] old_data;
  wire [8:0] old_position;
  wire [74:0] old_metadata;
  wire [7:0] old_reasons;
  starlink_pss_realtime_result_guard_ce6a885e_golden #(
    .WATCHDOG_CYCLES(WATCHDOG), .USE_COMPLETED_INPUT_FAULT(COMPLETED),
    .USE_PHASE_INPUT_FAULT(PHASE_INPUT), .USE_PREFLIGHT_REASON_ONLY(PREFLIGHT)) old_guard (
    .clk(clk), .resetn(resetn), .job_valid(job_valid), .job_ready(old_ready),
    .job_descriptor(job_descriptor), .input_bank_reserved(input_bank_reserved),
    .output_bank_reserved(output_bank_reserved), .certified_input_beat(certified_input_beat),
    .certified_input_complete(certified_input_complete), .final_fence_certified(final_fence_certified),
    .external_fault_now(external_fault_now), .phase_input_fault_now(phase_input_fault_now),
    .completed_input_certified(completed_input_certified), .completed_input_fault_now(completed_input_fault_now),
    .preflight_fault_evidence_now(preflight_fault_evidence_now), .core_event_frame_started(core_event_frame_started),
    .core_output_tdata(core_output_tdata), .core_output_tuser(core_output_tuser),
    .core_output_tvalid(core_output_tvalid), .core_output_tlast(core_output_tlast),
    .core_status_tdata(core_status_tdata), .core_status_tvalid(core_status_tvalid),
    .mailbox_input_ready(mailbox_input_ready), .mailbox_input_fault(mailbox_input_fault),
    .mailbox_input_valid(old_valid), .mailbox_private_valid(old_private_valid),
    .mailbox_commit_valid(old_commit_valid), .mailbox_input_data(old_data),
    .mailbox_input_position(old_position), .mailbox_input_last(old_last), .mailbox_input_metadata(old_metadata),
    .busy(old_busy), .commit_pulse(old_commit), .protocol_fault(old_fault), .fault_reasons(old_reasons)
  );
  task check;
    begin
      checks = checks + 1;
      if (mailbox_current_fault_now === 1'b1 && inverse_phase !== 1'b1)
        $fatal(1, "FORWARD_CALLER_PHASE_INVARIANT_BROKEN");
      if (mailbox_input_fault !== (forward_mailbox_fault || mailbox_current_fault_now))
        $fatal(1, "FORWARD_CALLER_FAULT_SPLIT_BROKEN");
      if (actual_public !== {old_ready, old_valid, old_private_valid, old_commit_valid,
          old_data, old_position, old_last, old_metadata, old_busy, old_commit, old_fault, old_reasons})
        $fatal(1, "FORWARD_OLD_PUBLIC_MISMATCH");
      if (actual_forward_valid !== (ENABLED && old_valid && !inverse_phase))
        $fatal(1, "FORWARD_RETIREMENT_MISMATCH phase=%0d sticky=%0d old=%0d new=%0d",
          inverse_phase, forward_mailbox_fault, old_valid, actual_forward_valid);
      if (resetn && old_valid && !inverse_phase) forward_cycles = forward_cycles + 1;
      if (resetn && mailbox_current_fault_now) inverse_current_faults = inverse_current_faults + 1;
      if (resetn && !inverse_phase && forward_mailbox_fault) sticky_forward_faults = sticky_forward_faults + 1;
    end
  endtask
  always @(posedge clk or negedge clk) begin #0.001; check(); end
endmodule
// SPDX-License-Identifier: GPL-2.0
// Used by the explicitly opted-in realtime shared-XFFT service; the default
// non-realtime service is unchanged. Physical qualification is separate.
// One reserved result bank plus one 52-bit return slot; no extra payload RAM.
// The final word stays here until independent status and all explicitly
// certified premises pass. An explicit-commit mailbox may privately rewrite
// that word before qualification, but must not publish on private-write valid.
//
// CALLER OBLIGATIONS (not established by this module):
// - resetn is a common, synchronously released epoch for BOTH mailbox clocks;
// - input_bank_reserved means a complete, checked/prefetched 512-word bank;
// - output_bank_reserved is exclusive whole-bank ownership, not just READY;
// - certified_input_beat denotes an actually delivered, fully checked core beat;
// - certified_input_complete certifies the input framing/identity checks;
// - external_fault_now includes immediate starvation/input/core/ownership faults;
// - final_fence_certified proves all potentially corrupting delayed events have
//   been observed or excluded. NO vendor-event latency bound is inferred here.
// A pulse/claim from an unqualified caller cannot make a qualified FFT service.
// There is no output/status backpressure to the realtime core. Unexpected
// transport stalls fault closed. A new job waits for the mailbox's actual ACK.
`timescale 1ns/1ps

module starlink_pss_realtime_result_guard_ce6a885e_golden #(
  parameter integer WATCHDOG_CYCLES = 8192,
  // Opt in only when the caller proves idle input is reset/completed, and
  // final qualification and the full ACK interval imply completed input.
  // The supplied predicate must equal external_fault_now | both input
  // certificates in these phases while the epoch is not already quarantined.
  // Default callers retain the independent, unrestricted input checks.
  parameter integer USE_PHASE_INPUT_FAULT = 0,
  // Separately opt in for an occupied, checked return. The caller must prove
  // that every such return has registered completed input, and provide an
  // exact external-fault predicate in that phase. The certificate closes the
  // independent input guard, so both input certificates must then be zero.
  // Full faults_now/reasons are retained for ALL phases. Defaults unchanged.
  parameter integer USE_COMPLETED_INPUT_FAULT = 0,
  // Caller guarantees no payload/configuration/publication during preflight.
  // A rejected preflight may privately admit on this edge, but this reason Q
  // must quarantine it before any emitted start or public evidence. This input
  // is deliberately NOT a combinational admission/active-publication predicate.
  parameter integer USE_PREFLIGHT_REASON_ONLY = 0
) (
  input wire clk,
  input wire resetn,
  input wire job_valid,
  output wire job_ready,
  input wire [69:0] job_descriptor,
  input wire input_bank_reserved,
  input wire output_bank_reserved,
  input wire certified_input_beat,
  input wire certified_input_complete,
  input wire final_fence_certified,
  input wire external_fault_now,
  input wire phase_input_fault_now,
  input wire completed_input_certified,
  input wire completed_input_fault_now,
  input wire preflight_fault_evidence_now,
  input wire core_event_frame_started,
  input wire [47:0] core_output_tdata,
  input wire [23:0] core_output_tuser,
  input wire core_output_tvalid,
  input wire core_output_tlast,
  input wire [7:0] core_status_tdata,
  input wire core_status_tvalid,
  output wire mailbox_input_valid,
  output wire mailbox_private_valid,
  // Separate final-only authorization for explicit-commit mailboxes. Ordinary
  // mailbox_input_valid remains unchanged for nonfinal result retirement.
  output wire mailbox_commit_valid,
  input wire mailbox_input_ready,
  input wire mailbox_input_fault,
  output wire [35:0] mailbox_input_data,
  output wire [8:0] mailbox_input_position,
  output wire mailbox_input_last,
  output wire [74:0] mailbox_input_metadata,
  output wire busy,
  output reg commit_pulse,
  output wire protocol_fault,
  output reg [7:0] fault_reasons
);
  localparam integer AGE_WIDTH = $clog2(WATCHDOG_CYCLES);
  initial begin
    if (USE_PHASE_INPUT_FAULT != 0 && USE_PHASE_INPUT_FAULT != 1)
      $fatal(1, "USE_PHASE_INPUT_FAULT must be zero or one");
    if (USE_COMPLETED_INPUT_FAULT != 0 && USE_COMPLETED_INPUT_FAULT != 1)
      $fatal(1, "USE_COMPLETED_INPUT_FAULT must be zero or one");
    if (USE_PREFLIGHT_REASON_ONLY != 0 && USE_PREFLIGHT_REASON_ONLY != 1)
      $fatal(1, "USE_PREFLIGHT_REASON_ONLY must be zero or one");
    if (WATCHDOG_CYCLES < 2 || WATCHDOG_CYCLES > 1048576)
      $fatal(1, "realtime result guard requires a finite 2..1048576 cycle watchdog");
  end

  reg active_private, awaiting_ack;
  // faults_now is captured in fault_reasons on the same edge that formerly
  // cleared active. Quarantine that private occupancy through the registered
  // fault bank instead of routing the complete fault tree to another D pin.
  // Effective active still falls on that edge, including for exact next-cycle
  // orphan-event classification. The private bit never authorizes publication.
  wire active = active_private && !protocol_fault;
  reg [69:0] descriptor;
  reg [9:0] input_count, output_count;
  reg input_complete_seen, frame_seen, status_seen, exponent_seen;
  reg [4:0] status_exponent, output_exponent;
  reg [AGE_WIDTH-1:0] age;
  reg return_occupied, return_last;
  wire return_valid = return_occupied && active;
  reg [35:0] return_data;
  reg [8:0] return_position;
  reg [4:0] return_exponent;

  // Exact equality after a possible delivered beat; no wide increment is
  // needed just to decide whether the effective count is 512. This does not
  // remove or defer the independent input guard's ordinal/metadata check.
  wire effective_input_full = (input_count == 511 && certified_input_beat) ||
    (input_count == 512 && !certified_input_beat);
  wire effective_input_complete = input_complete_seen || certified_input_complete;
  wire effective_frame_seen = frame_seen || core_event_frame_started;
  wire reservation_error = active && (!output_bank_reserved ||
    (!input_complete_seen && !input_bank_reserved));
  wire input_error = (certified_input_beat &&
    (!active || input_complete_seen || input_count == 512)) ||
    (certified_input_complete &&
    (!active || input_complete_seen || !effective_input_full));
  wire frame_error = core_event_frame_started &&
    (!active || frame_seen || (input_count == 0 && !certified_input_beat));
  wire status_error = core_status_tvalid &&
    (!active || status_seen || core_status_tdata[7:5] != 0 ||
     (exponent_seen && core_status_tdata[4:0] != output_exponent));
  // Preserve the existing BFP18 layout: two 18-bit values in 24-bit AXI slots;
  // TUSER is {3'b0, exponent[4:0], 7'b0, XK_INDEX[8:0]}.
  // The unused upper component-slot bits are ignored, as in the old adapter.
  wire output_error = core_output_tvalid &&
    (!active || output_count == 512 || !effective_input_complete ||
     !effective_input_full || !effective_frame_seen ||
     core_output_tuser[15:9] != 0 || core_output_tuser[23:21] != 0 ||
     core_output_tuser[8:0] != output_count[8:0] ||
     core_output_tlast != (output_count == 511) ||
     (exponent_seen && core_output_tuser[20:16] != output_exponent) ||
     (status_seen && core_output_tuser[20:16] != status_exponent) ||
     (core_status_tvalid && core_output_tuser[20:16] != core_status_tdata[4:0]));
  wire slot_error = active && return_valid &&
    ((!return_last && !mailbox_input_ready) ||
     (core_output_tvalid && (return_last || !mailbox_input_ready)));
  wire watchdog_error = active && age == WATCHDOG_CYCLES - 1;
  wire [7:0] faults_now = {watchdog_error, slot_error, output_error, status_error,
    frame_error, input_error, reservation_error, external_fault_now || mailbox_input_fault};
  wire fault_now = |faults_now;
  assign protocol_fault = |fault_reasons;
  assign busy = active || awaiting_ack;
  // Admission already requires !active. In that phase reservation, slot and
  // watchdog errors are false; every input/frame/status/output event is an
  // error regardless of its payload. This is exactly faults_now restricted
  // to idle, not a delayed or weaker admission fence. Keep active-job payload
  // validation off this path to the caller's admission/state controls.
  wire phase_input_fault = USE_PHASE_INPUT_FAULT ? phase_input_fault_now :
    (external_fault_now || certified_input_beat || certified_input_complete);
  wire idle_fault_now = phase_input_fault || mailbox_input_fault ||
    core_event_frame_started || core_status_tvalid || core_output_tvalid;
  assign job_ready = resetn && !protocol_fault && !idle_fault_now &&
    !active && !awaiting_ack && !return_valid &&
    input_bank_reserved && output_bank_reserved && mailbox_input_ready;
  wire job_accept = job_valid && job_ready;

  // Only REGISTERED complete evidence opens the final write. A coincident new
  // status, duplicate status, frame event, raw extra word, timeout or external
  // fault still participates in faults_now and directly vetoes that same edge.
  wire final_qualified = input_count == 512 && input_complete_seen &&
    output_count == 512 && frame_seen && exponent_seen && status_seen &&
    output_exponent == status_exponent && final_fence_certified;
  // With a held final word AND final_qualified, every new raw input/frame/
  // status/output event is illegal, input ownership is already retired, and
  // the remaining immediate faults are output ownership, transport/external
  // faults and the watchdog. This is faults_now restricted to that phase.
  // Keep the full fault tree and exact reason accumulation for every phase;
  // never use this reduced predicate for a nonfinal or unqualified word.
  wire final_fault_now = phase_input_fault || mailbox_input_fault ||
    !output_bank_reserved ||
    core_event_frame_started || core_status_tvalid || core_output_tvalid || watchdog_error;
  // A visible held return survived the preceding edge's full output_error.
  // Therefore input_count=512, input_complete_seen, frame_seen and exponent_seen
  // are registered facts. With the caller's closed-input certificate, neither
  // a new input beat nor its metadata comparator can affect this phase. Keep
  // live output/status validation: first matching status is legal NONFINAL;
  // treating every status as a fault here would silently change behavior.
  wire completed_output_error = core_output_tvalid &&
    (output_count == 512 || core_output_tuser[15:9] != 0 ||
     core_output_tuser[23:21] != 0 || core_output_tuser[8:0] != output_count[8:0] ||
     core_output_tlast != (output_count == 511) ||
     core_output_tuser[20:16] != output_exponent ||
     (status_seen && core_output_tuser[20:16] != status_exponent) ||
     (core_status_tvalid && core_output_tuser[20:16] != core_status_tdata[4:0]));
  wire completed_return_fault_now = completed_input_fault_now || mailbox_input_fault ||
    !output_bank_reserved || core_event_frame_started || status_error ||
    completed_output_error || slot_error || watchdog_error;
  wire completed_final_fault_now = completed_input_fault_now || mailbox_input_fault ||
    !output_bank_reserved || core_event_frame_started || core_status_tvalid ||
    core_output_tvalid || watchdog_error;
  wire return_phase_allowed = !USE_COMPLETED_INPUT_FAULT || completed_input_certified;
  wire nonfinal_public_fault = USE_COMPLETED_INPUT_FAULT ? completed_return_fault_now : fault_now;
  wire final_public_fault = USE_COMPLETED_INPUT_FAULT ? completed_final_fault_now : final_fault_now;
  assign mailbox_input_valid = resetn && active && !protocol_fault && return_valid &&
    return_phase_allowed &&
    ((!return_last && !nonfinal_public_fault) || (return_last && final_qualified && !final_public_fault));
  // A prior certified return word may enter exclusively owned private RAM on
  // a simultaneous new fault. The full current fault still vetoes retirement
  // and publication above, clears return_valid below, and quarantines the
  // epoch. NEVER connect this signal to a legacy publish-on-final mailbox.
  assign mailbox_private_valid = resetn && active && !protocol_fault && return_valid;
  assign mailbox_input_data = return_data;
  assign mailbox_input_position = return_position;
  assign mailbox_input_last = return_last;
  // Same ordering as the existing service: descriptor, then new exponent.
  assign mailbox_input_metadata = {descriptor, return_exponent};
  wire mailbox_accept = mailbox_input_valid && mailbox_input_ready;
  // Expand the final branch explicitly: return_last excludes the nonfinal
  // branch of mailbox_input_valid. This is the same handshake on the same
  // edge, without unnecessarily reconverging the full nonfinal fault tree
  // onto final occupancy/ACK controls. No publication condition is omitted.
  assign mailbox_commit_valid = resetn && active && !protocol_fault && return_valid &&
    return_phase_allowed && return_last && final_qualified && !final_public_fault;
  wire final_commit = mailbox_commit_valid && mailbox_input_ready;

  always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
      active_private <= 0;
      awaiting_ack <= 0;
      descriptor <= 0;
      input_count <= 0;
      output_count <= 0;
      input_complete_seen <= 0;
      frame_seen <= 0;
      status_seen <= 0;
      exponent_seen <= 0;
      status_exponent <= 0;
      output_exponent <= 0;
      age <= 0;
      return_occupied <= 0;
      return_last <= 0;
      return_data <= 0;
      return_position <= 0;
      return_exponent <= 0;
      commit_pulse <= 0;
      fault_reasons <= 0;
    end else begin
      commit_pulse <= final_commit;
      fault_reasons <= fault_reasons | faults_now |
        {7'b0, (USE_PREFLIGHT_REASON_ONLY && preflight_fault_evidence_now)};
      // Stage only private descriptor bits while idle. Every admitted job
      // satisfies this predicate and captures the same descriptor on the same
      // edge, without putting the active-job fault cone on 70 register enables.
      // Rejected requests may change invalid metadata, never validity or bank
      // ownership. A current fault still quarantines the epoch below; active
      // jobs and the full ACK interval (including its clearing edge) hold the
      // accepted descriptor. Reset purges any speculative value before reuse.
      if (!active && !awaiting_ack && !protocol_fault && job_valid)
        descriptor <= job_descriptor;
      // Job observations are private while inactive. Clear them during that
      // phase, including the ACK wait, rather than routing the entire current
      // fault/mailbox framing cone through their job_accept reset muxes. Every
      // accepted job is inactive on this edge, so it still starts at zero.
      // Idle events remain errors independent of these values; active checks,
      // same-edge publication veto and sticky quarantine are unchanged. Keep
      // faulted private observations frozen until the common epoch reset.
      if (!active && !protocol_fault) begin
        input_count <= 0;
        output_count <= 0;
        input_complete_seen <= 0;
        frame_seen <= 0;
        status_seen <= 0;
        exponent_seen <= 0;
      end
      // Account the raw arriving beat even if it triggers quarantine. This
      // counter is private; malformed data still cannot become a valid return
      // word or publish. Saturate beyond the one allowed block rather than wrap.
      if (active && !protocol_fault && core_output_tvalid && output_count < 513)
        output_count <= output_count + 1'b1;
      // Speculatively capture ONLY private payload on the arriving edge, so
      // its 51-bit register enable need not traverse the full validation tree.
      // Current faults still clear return_valid below and veto mailbox_input_valid
      // immediately. Sticky quarantine prevents this payload gaining validity
      // later; the epoch reset clears it before another job can be admitted.
      if (active && !protocol_fault && core_output_tvalid) begin
        return_data <= {core_output_tdata[41:24], core_output_tdata[17:0]};
        return_position <= core_output_tuser[8:0];
        return_last <= core_output_tlast;
        return_exponent <= core_output_tuser[20:16];
      end
      // Private watchdog state need not wait for the complete current-cycle
      // fault cone. Admission occurs while inactive, so it still starts at
      // zero; every healthy active edge and the immediate deadline veto are
      // unchanged. On a fault edge only this private age may advance before
      // quarantine clears active. No publication or fault check is delayed.
      if (!active) age <= 0;
      else age <= age + 1'b1;
      // These are private job observations, not publication authority. Capture
      // them without routing the complete current fault tree through every
      // counter/flag/exponent enable. A simultaneous fault still clears active
      // and return_valid below and latches exact reasons on this same edge.
      // Sticky quarantine prevents any changed private observation from
      // authorizing publication or a new job before the common epoch reset.
      // Once inactive, raw events are errors regardless of these private values.
      if (active && !protocol_fault) begin
        if (certified_input_beat) input_count <= input_count + 1'b1;
        if (certified_input_complete) input_complete_seen <= 1;
        if (core_event_frame_started) frame_seen <= 1;
        if (core_status_tvalid) begin
          status_seen <= 1;
          status_exponent <= core_status_tdata[4:0];
        end
        if (core_output_tvalid) begin
          if (!exponent_seen) output_exponent <= core_output_tuser[20:16];
          exponent_seen <= 1;
        end
      end
      // job_accept is already qualified while idle. final_commit is already
      // qualified by the unchanged same-edge final publication fence. A new
      // fault clears effective active/return_valid through fault_reasons on
      // this edge; clearing these hidden occupancy bits can wait until next.
      if (protocol_fault) active_private <= 0;
      else if (job_accept) active_private <= 1;
      else if (final_commit) active_private <= 0;

      if (!active) return_occupied <= 0;
      else begin
        if (!return_last && mailbox_input_ready) return_occupied <= 0;
        if (core_output_tvalid) return_occupied <= 1;
        // Final commit clears effective active, hence return_valid, on this
        // edge. The hidden occupied bit is cleared on the next idle edge.
      end

      // ACK wait is inactive. The optional caller-specific input predicate
      // is exact only under its completed-input contract; all other callers
      // retain idle_fault_now's full independent event checks.
      // Retain a faulted ACK wait and never clear it on a coincident orphan.
      if (awaiting_ack && mailbox_input_ready && !protocol_fault && !idle_fault_now)
        awaiting_ack <= 0;
      if (final_commit) awaiting_ack <= 1;
    end
  end
endmodule
