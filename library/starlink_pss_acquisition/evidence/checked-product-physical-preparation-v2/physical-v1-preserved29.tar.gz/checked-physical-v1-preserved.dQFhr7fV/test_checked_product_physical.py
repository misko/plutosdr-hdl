"""Offline-only physical adapter checks; synthetic admission is explicitly mocked.

No vendor process and no claim that a checked-product actual result passed.
The real generated admission remains unchanged in every copied helper.
"""
import hashlib
import json
import os
import re
import runpy
import shutil
import subprocess
from pathlib import Path

import pytest

ACQ = Path(__file__).resolve().parents[2] / "hdl/library/starlink_pss_acquisition"
ACTUAL = Path("/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/checked-product-actual-prepared-v1")
GEN = runpy.run_path(str(ACQ / "prepare_checked_product_physical.py"))
BODY, EDITS, OWNER = GEN["build"](ACQ)
P1 = GEN["restore"](BODY, EDITS)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def namespace(path):
    data = {"__file__": str(path)}
    exec(compile(BODY, str(path), "exec"), data)
    return data


def test_complete_old_helper_inverse_and_fixed_runtime():
    assert hashlib.sha256(P1.encode()).hexdigest() == GEN["P1_HELPER_SHA"]
    helper = namespace(ACQ / "not_executed.py")
    assert len(helper["RTL"]) == 14 and len(set(helper["RTL"])) == 14
    binding = runpy.run_path(str(ACQ / "prepare_checked_product_actual.py"))
    assert set(helper["RTL"]) == set(binding["RUNTIME_SHA"])
    for name, expected in binding["RUNTIME_SHA"].items():
        assert digest(ACQ / name) == digest(ACTUAL / "frozen_sources" / name) == expected
    assert digest(ACQ / "run_exact_control_synthesis.py") == OWNER
    assert helper["SETTINGS"]["CHECKED_PRODUCT_BANK"] == 1
    assert len(helper["SETTINGS"]) == 11


@pytest.mark.parametrize("before,after", [
    ("rtl_count\": 14", "rtl_count\": 13"),
    ("CHECKED_PRODUCT_BANK=$checked_product", "CHECKED_PRODUCT_BANK=0"),
    ("timed_out\": False", "timed_out\": True"),
    ("timeout=90", "timeout=91"),
])
def test_inverse_rejects_mutated_whole_body(before, after):
    assert before in BODY
    with pytest.raises(ValueError):
        GEN["restore"](BODY.replace(before, after, 1), EDITS)


@pytest.fixture
def mocked_prepared(tmp_path):
    tools = tmp_path / "tools"
    tools.mkdir()
    helper_file = tools / "prepare_exact_control_physical.py"
    helper_file.write_text(BODY)
    helper = namespace(helper_file)
    for name in (*helper["FIXED"], "run_exact_control_synthesis.py"):
        shutil.copyfile(ACQ / name, tools / name)
    # Explicit test-local mock only; the emitted helper still has real admission.
    actual = tmp_path / "stub_actual"
    source = actual / "frozen_sources"
    source.mkdir(parents=True)
    for name in helper["SOURCE_NAMES"]:
        if name not in ("fft_bank_owned_resource_probe.xdc", "fft_bank_owned_synth_threads.tcl"):
            shutil.copyfile(ACTUAL / "frozen_sources" / name, source / name)
    report = {"actual_directory": str(actual), "settings": helper["SETTINGS"],
        "source_sha256": {p.name: digest(p) for p in source.iterdir()},
        "qualified_observer": {"scope": "TEST_STUB_NOT_ACTUAL_ACCEPTANCE"}}
    helper["verify_actual"].__globals__["verify_actual"] = lambda path: report
    prepared = tmp_path / "prepared"
    result = helper["prepare"](actual, prepared)
    assert result["rtl_count"] == 14 and result["checked_product"] == 1
    assert (prepared / "prepare_exact_control_physical.py").read_text() == BODY
    (tmp_path / "TEST_SCOPE.txt").write_text("Mocked admission; no actual or vendor qualification.\n")
    return helper, prepared


def test_copier_complete_closure_and_literal_physical_suffix(mocked_prepared):
    helper, prepared = mocked_prepared
    assert len((prepared / "SHA256SUMS").read_text().splitlines()) == 25
    new = (prepared / "synthesize_exact_control_prepared.tcl").read_text()
    old = {}
    exec(compile(P1, "old", "exec"), old)
    original = (ACQ / "synthesize_fft_bank_owned_slice.tcl").read_text()
    previous = old["adapt_synthesis"](original)
    # The synthesis implementation body, part/factory/strategy/constraints and
    # resource/zero-BB reports are untouched; only declarations/receipts differ.
    anchor = "set_property STEPS.SYNTH_DESIGN.ARGS.FLATTEN_HIERARCHY"
    new_tail = new[new.index(anchor):].replace(
        "; checked_product_bank=$checked_product", "")
    assert new_tail == previous[previous.index(anchor):]
    for name in (*helper["FIXED"], "run_exact_control_synthesis.py"):
        path = prepared / (name if name in ("route_completed_input_fence.tcl", "run_exact_control_synthesis.py")
            else "synthesize_fft_bank_owned_slice.original.tcl" if name == "synthesize_fft_bank_owned_slice.tcl"
            else "frozen_sources/" + name)
        assert digest(path) == digest(ACQ / name)
    names = re.search(r"set rtl_names \{([^}]+)\}", new)[1].split()
    assert {name + ".v" for name in names} == set(helper["RTL"]) and len(names) == 14
    assert "set_property top starlink_pss_fft_bank_owned_checked_product " in new
    copied = prepared.parent / "copied"
    shutil.copytree(prepared / "frozen_sources", copied)
    shutil.copyfile(prepared / "synthesize_exact_control_prepared.tcl", copied / "synthesize_exact_control_prepared.tcl")
    assert helper["verify_prepared"](prepared, copied)["rtl_count"] == 14
    for name in helper["RTL"]:
        path = copied / name
        body = path.read_bytes()
        path.write_bytes(body + b"\n")
        with pytest.raises(ValueError, match="copied synthesis source differs"):
            helper["verify_prepared"](prepared, copied)
        path.write_bytes(body)


def tcl(body, tmp_path):
    path = tmp_path / "mock.tcl"
    path.write_text(body)
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONHOME", "PYTHONPATH", "LD_LIBRARY_PATH", "PYTHONOPTIMIZE")}
    run = subprocess.run(["tclsh", str(path)], capture_output=True, text=True, env=env, timeout=15)
    (tmp_path / "stdout.log").write_text(run.stdout)
    (tmp_path / "stderr.log").write_text(run.stderr)
    return run


@pytest.mark.parametrize("mutation", ["healthy", "missing", "zero", "duplicate", "conflict", "lowercase", "unknown"])
def test_exact_checked_generic_readback(mutation, tmp_path):
    helper = namespace(tmp_path / "not_executed.py")
    options = "REGISTERED_SCHEDULING DISTRIBUTED_FAST_FAULT PRIVATE_NEXT_START_SCRATCH PER_CAUSE_FAULT_CDC PRIVATE_ROM_READ_AHEAD PRIVATE_BLOCK_METADATA_READ_AHEAD PRODUCER_LOCAL_FINAL_FENCE CHECKED_PRODUCT_BANK".split()
    values = [name + "=1" for name in options]
    if mutation == "missing":
        values.pop()
    elif mutation == "zero":
        values[-1] = "CHECKED_PRODUCT_BANK=0"
    elif mutation == "duplicate":
        values.append(values[-1])
    elif mutation == "conflict":
        values.append("CHECKED_PRODUCT_BANK=0")
    elif mutation == "lowercase":
        values[-1] = values[-1].lower()
    elif mutation == "unknown":
        values[-1] = "CHECKED_PRODUCT_BANK=x"
    pre = "\n".join(f"set {name} 1" for name in (
        "registered", "distributed", "scratch", "per_cause", "rom_word", "rom_metadata", "producer_final", "checked_product"))
    body = pre + "\nproc get_filesets {args} {return sources_1}\nproc get_property {args} {return {" + " ".join(values) + "}}\n"
    run = tcl(body + helper["GENERIC_CHECK"] + '\nputs "GENERIC_OFFLINE_STUB_PASS"\n', tmp_path)
    assert (run.returncode == 0) == (mutation == "healthy"), run.stdout + run.stderr


def test_full_tcl_admission_stops_before_create_project(mocked_prepared, tmp_path):
    _, prepared = mocked_prepared
    output = tmp_path / "never_vendor"
    # Intercept only Python admission calls; all hashing/copying remains real.
    stub = '''proc version {args} {return 2022.2}
proc set_param {args} {}
proc create_project {args} {puts "OFFLINE_CREATE_PROJECT_TRAP"; exit 0}
rename exec real_exec
proc exec {args} {
  if {[lindex $args 0] eq "env"} {
    if {[lsearch -exact $args --verify] < 0 || [lsearch -exact $args -B] < 0} {error "unexpected child"}
    return "TEST_STUB_ADMISSION_NOT_ACTUAL_PASS"
  }
  return [real_exec {*}$args]
}
'''
    program = stub + f"set argc 3\nset argv [list {{{output}}} {{{prepared}}} {digest(prepared / 'SHA256SUMS')}]\nsource {{{prepared / 'synthesize_exact_control_prepared.tcl'}}}\n"
    result = tcl(program, tmp_path)
    assert result.returncode == 0 and result.stdout.count("OFFLINE_CREATE_PROJECT_TRAP") == 1
    assert not (output / "project").exists()
    assert len(list((output / "frozen_sources").glob("*.v"))) == 14


def test_pending_actual_is_rejected_without_output(tmp_path):
    helper = namespace(tmp_path / "not_executed.py")
    actual = tmp_path / "candidate"
    actual.mkdir()
    with pytest.raises(FileNotFoundError):
        helper["prepare"](actual, tmp_path / "rejected")
    assert not (tmp_path / "rejected").exists()


@pytest.mark.parametrize("key,bad", [
    ("vendor_exit", 1), ("vendor_exit", False), ("timed_out", True),
    ("interruption", "Timeout"), ("source_pins_unchanged", False),
    ("live_sources_unchanged", False), ("generated_wrapper_matches_known", False),
    ("result_exit", 1), ("functional_accepted", False), ("physical_qualified", True),
    ("deployment_eligible", True),
])
def test_original_actual_failure_or_timeout_not_admitted(key, bad, tmp_path):
    helper = namespace(tmp_path / "not_executed.py")
    owner = tmp_path / "checked-actual-parent.xtGiofa6"
    owner.mkdir()
    result = {"vendor_exit": 0, "timed_out": False, "interruption": None,
        "source_pins_unchanged": True, "live_sources_unchanged": True,
        "generated_wrapper_matches_known": True, "result_exit": 0,
        "functional_accepted": True, "physical_qualified": False, "deployment_eligible": False}
    result[key] = bad
    (owner / "outcome.json").write_text(json.dumps(result))
    with pytest.raises(ValueError, match="pending/failed/unqualified"):
        helper["verify_actual"](tmp_path / "candidate")


@pytest.mark.parametrize("kind", ["output", "tools", "alias"])
def test_no_overwrite_or_alias(kind, tmp_path):
    output = tmp_path / "prepared"
    if kind == "output":
        output.mkdir()
    elif kind == "tools":
        output.with_name(output.name + "-tools").mkdir()
    else:
        output.symlink_to(tmp_path / "nonexistent")
    with pytest.raises((ValueError, FileExistsError)):
        GEN["prepare"](tmp_path / "unused_actual", output)
