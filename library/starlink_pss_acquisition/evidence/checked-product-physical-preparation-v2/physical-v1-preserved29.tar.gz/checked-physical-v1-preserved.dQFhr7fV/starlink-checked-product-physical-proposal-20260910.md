# Checked-product physical recipe: offline draft, admission closed

The source-specific draft reuses the previous P1 copier, actual FFT factory,
constraints, synthesis body and external owner. No synthesis or route was run.
The root-owned checked actual30484 subsequently failed its final nominal drain
sampling gate; the new physical admission rejects that original outcome. This
draft is not an admitted physical source bundle and cannot authorize a run.

## Minimal source delta

New generator `hdl/library/starlink_pss_acquisition/prepare_checked_product_physical.py`
SHA9454bd225b7888d90fba6e2afb288b35b672060f38495b111dcf52176a271e6c
derives the complete old P1 helper d22bda33 through13 literal edits. The full
inverse restores that helper and composes through the old ROM/C1/base inverses.

The six additional files make the exact frozen14-module closure: checked top,
checked input guard, observed result guard, observed read queue, observed sealed
issuer and publication-only bank. Original P1 fallback and canonical source/
output mailbox remain included. Only the selected top name changes to
`starlink_pss_fft_bank_owned_checked_product`; explicit CHECKED_PRODUCT_BANK1
joins existing R/D/S/C/K/M/P1 generic setting and strict readback. The actual
settings still require extras1/FAST175/QUICK0. No arithmetic/scheduler union.

Unchanged: xc7z010clg400-1; FFT9.1 realtime512/18-bit/BFP factory0795ea7e;
kernel694d0d9b; source100/island175 resource XDCbac30eff; synthesis threads
aec974f2; rebuilt/AreaOptimized_high and OOC options; IP Flow_AreaOptimized_high;
threshold4; maxThreads2; route Tcl0873675f. The factory's existing200MHz target
is not an achieved island clock claim. The unchanged d0f36ce2 external owner
retains failure-side source audits, unique completion marker, eight nonempty
products, DCP, zero-black-box gate and process-vs-verified-completion distinction.

The old raw217/paired-CSV admission function is replaced explicitly, not relaxed:
require the exact checked84 inventory, all14 runtime pins, full inherited CLI,
original root owner d64dfb70, typed original exit/timeout/outcome, source pre/post
receipts, after-only19 IP hashes, complete frozen changed-latency result gate,
and exact runner completion. The accepted result scope would remain numerical/
qualified-status/ownership/CDC/ROM/current-fault/service<=5215, never raw217 or
physical qualification. Failed or pending owner outcome fails before copying.

Generated helper SHA c74c5e30ec73eb208345a8fde8742a89784ebe78045012f8ea681a556618a66e.
Generated Tcl SHA b01efa80e900af1d19765a0ed06703fc7c3d1d86d32ee5d09d3ce225c75c602f.
These are generated draft identities, not successful physical preparation pins.
The current draft deliberately binds the failed actual-v1; any future successor
actual source/owner must be reviewed and rebound explicitly before admission.

## Offline evidence and next gate

`tests/starlink_oracle/test_checked_product_physical.py`
SHA6abb543f8382ea6ffd5cf772ce70e890ed8903e37c4dda8a9e3e065e6c17b85c:
29PASS0.21s, terminal0, retained in
`/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/checked-physical-offline-v1.KHsVSfl5`.
Full-body inverses; unchanged synthesis suffix and physical dependencies;
14-source copied corruption checks; missing/zero/duplicate/conflicting/case/X
CHECKED generic readback; pending/failing/timeout original outcome rejection;
and no-overwrite/alias checks pass. A test-local admission mock copies25 files
and runs Tcl only to a `create_project` trap. Those stubs are labeled as such;
they neither simulate FFT nor prove actual admission. The emitted helper keeps
its real gate. A separate read-only call against original30484 reports
`ValueError: checked actual pending/failed/unqualified outcome`.

After a separately qualified successor actual and reviewed source-specific
rebind, the existing command shape would remain:

```sh
env -u PYTHONHOME -u PYTHONPATH -u LD_LIBRARY_PATH -u PYTHONOPTIMIZE \
  /home/mouse9911/gits/pluto-plus-utils/.venv/bin/python -B \
  PREPARED/run_exact_control_synthesis.py --execute-synthesis \
  --prepared PREPARED --expected REVIEWED_INVENTORY_SHA --new-run UNIQUE_RECOVERY_DIRECTORY
```

There is no approved path/hash filling those placeholders now. Estimated logic
state remains+558 bits versus P1 before optimization, same512x36 payload RAM;
this is not mapped area. Prior P1 route failure remains immutable. Any DCP,
timing/hold/CDC/reset/IO interpretation and route approval are separate gates.
