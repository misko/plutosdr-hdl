proc version {args} {return 2022.2}
proc set_param {args} {}
proc create_project {args} {puts "OFFLINE_CREATE_PROJECT_TRAP"; exit 0}
rename exec real_exec
proc exec {args} {
  if {[lindex $args 0] eq "env"} {
    if {[lsearch -exact $args --verify] < 0 || [lsearch -exact $args -B] < 0} {error "unexpected child"}
    return "TEST_STUB_ADMISSION_NOT_ACTUAL_PASS"
  }
  return [real_exec {*}$args]
}
set argc 3
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/checked-physical-v2-offline.FxY6n676/pytest/test_full_tcl_admission_stops_0/never_vendor} {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/checked-physical-v2-offline.FxY6n676/pytest/test_full_tcl_admission_stops_0/prepared} 466412782b555741b93c08be9ba42b4fcd4fc3605ee5a00bff3fa6311352722c]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/checked-physical-v2-offline.FxY6n676/pytest/test_full_tcl_admission_stops_0/prepared/synthesize_exact_control_prepared.tcl}
