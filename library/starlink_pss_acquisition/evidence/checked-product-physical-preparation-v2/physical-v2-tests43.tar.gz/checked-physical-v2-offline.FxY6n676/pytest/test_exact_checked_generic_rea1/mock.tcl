set registered 1
set distributed 1
set scratch 1
set per_cause 1
set rom_word 1
set rom_metadata 1
set producer_final 1
set checked_product 1
proc get_filesets {args} {return sources_1}
proc get_property {args} {return {REGISTERED_SCHEDULING=1 DISTRIBUTED_FAST_FAULT=1 PRIVATE_NEXT_START_SCRATCH=1 PER_CAUSE_FAULT_CDC=1 PRIVATE_ROM_READ_AHEAD=1 PRIVATE_BLOCK_METADATA_READ_AHEAD=1 PRODUCER_LOCAL_FINAL_FENCE=1}}
set physical_generics [get_property GENERIC [get_filesets sources_1]]
foreach {name value} [list REGISTERED_SCHEDULING $registered DISTRIBUTED_FAST_FAULT $distributed PRIVATE_NEXT_START_SCRATCH $scratch PER_CAUSE_FAULT_CDC $per_cause PRIVATE_ROM_READ_AHEAD $rom_word PRIVATE_BLOCK_METADATA_READ_AHEAD $rom_metadata PRODUCER_LOCAL_FINAL_FENCE $producer_final CHECKED_PRODUCT_BANK $checked_product] {
  if {[lsearch -exact $physical_generics ${name}=$value] < 0} { error "missing physical parameter $name" }
}
if {[lsearch -all -inline -glob $physical_generics PER_CAUSE_FAULT_CDC=*] ne [list PER_CAUSE_FAULT_CDC=1]} {
  error "requires exactly one explicit C1 physical parameter"
}
foreach name {PRIVATE_ROM_READ_AHEAD PRIVATE_BLOCK_METADATA_READ_AHEAD PRODUCER_LOCAL_FINAL_FENCE CHECKED_PRODUCT_BANK} {
  if {[lsearch -all -inline -glob $physical_generics ${name}=*] ne [list ${name}=1]} {
    error "requires exactly one explicit ROM physical parameter $name"
  }
}

puts "GENERIC_OFFLINE_STUB_PASS"
