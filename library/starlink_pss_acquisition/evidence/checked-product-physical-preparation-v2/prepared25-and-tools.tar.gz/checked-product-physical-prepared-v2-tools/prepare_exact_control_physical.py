"""Offline physical preparation from the exact passing combined actual run."""

import argparse
import hashlib
import json
import re
import runpy
import shutil
import subprocess
from pathlib import Path

ACTUAL_INVENTORY = "55288860074df8107d142c97bd69cb67bc71815f13bbb8bacc3b664b9547f5ea"
PYTHON = "/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python"
PYTHON_CHILD = f"env -u PYTHONHOME -u PYTHONPATH -u LD_LIBRARY_PATH {PYTHON} -B"
SETTINGS = {
    "REGISTERED_SCHEDULING": 1,
    "DISTRIBUTED_FAST_FAULT": 1,
    "PRIVATE_NEXT_START_SCRATCH": 1,
    "EXACT_EXTRA_EPOCHS": 1,
    "FAST_MHZ": 175,
    "QUICK_MUTATION": 0,
    "PER_CAUSE_FAULT_CDC": 1,
    "PRIVATE_ROM_READ_AHEAD": 1,
    "PRIVATE_BLOCK_METADATA_READ_AHEAD": 1,
    "PRODUCER_LOCAL_FINAL_FENCE": 1,
    "CHECKED_PRODUCT_BANK": 1,
}
RTL = tuple(
    f"starlink_pss_{name}.v"
    for name in (
        "fft_bank_owned_checked_product",
        "realtime_checked_product_input_guard",
        "realtime_result_guard_observe",
        "checked_product_read_observe",
        "product_sealed_observe",
        "epoch_sealed_publication_bank",
        "fft_bank_owned_product_fence",
        "realtime_input_guard",
        "realtime_result_guard",
        "block_mailbox",
        "product_fence_mailbox",
        "forward_kernel_join_read_ahead",
        "kernel_rom_read_ahead",
        "spectrum_product",
    )
)
FIXED = {
    "synthesize_fft_bank_owned_slice.tcl": "f843af0394cc680bf8344739ebe7adf7aece5d3db13e06b59b452d63372b9fe7",
    "route_completed_input_fence.tcl": "0873675fcec384f676a80b75b746460fbff2ecc3ee162f6111705ead2fad6d4a",
    "fft_bank_owned_resource_probe.xdc": "bac30eff84cc71d1f273104b716b388b55e51d33be10f9beaf1901232193ba3f",
    "fft_bank_owned_synth_threads.tcl": "aec974f2800f01285e888d1b188cd089534941922531914926a8e1b568d4c227",
    "create_shared_realtime_xfft_ip.tcl": "0795ea7e6aa981d78080ac22fa4ba6355da59d6829ceb409dda07a54f7f9420d",
}
SOURCE_NAMES = RTL + (
    "create_shared_realtime_xfft_ip.tcl",
    "upper_edge_pss_kernel_q17.mem",
    "fft_bank_owned_resource_probe.xdc",
    "fft_bank_owned_synth_threads.tcl",
)
LEGACY_ADMISSION = """set simlog [file join $evidence_dir project fft_bank_owned_slice.sim sim_1 behav xsim simulate.log]
set channel [open $simlog r]; set simulation [read $channel]; close $channel
if {[string first "FFT_BANK_OWNED_SLICE_PASS" $simulation] < 0 ||
    [regexp -nocase {fatal:|error:} $simulation]} { error "requires passing actual-core evidence" }
set prior_sources [file join $evidence_dir frozen_sources]
set channel [open [file join $evidence_dir scope.txt] r]; set sim_scope [read $channel]; close $channel
set registered [expr {[string first "registered_scheduling=1" $sim_scope] >= 0}]
if {$registered && [string first "REGISTERED_SCHEDULING_PASS" $simulation] < 0} {
  error "registered scheduling boundary tests did not pass"
}
"""
ADMISSION = f"""# Prepared-inventory identity is supplied separately by the reviewed caller.
set expected_prepared [lindex $argv 2]
set prepared_inventory [file join $evidence_dir SHA256SUMS]
if {{![regexp {{^[0-9a-f]{{64}}$}} $expected_prepared] ||
    [lindex [exec sha256sum $prepared_inventory] 0] ne $expected_prepared}} {{
  error "unexpected exact-control physical preparation"
}}
set audit_helper [file join $evidence_dir prepare_exact_control_physical.py]
set old_directory [pwd]; cd $evidence_dir
exec sha256sum -c SHA256SUMS --quiet
cd $old_directory
puts [exec {PYTHON_CHILD} $audit_helper --verify $evidence_dir --expected $expected_prepared]
source [file join $evidence_dir exact_physical_settings.tcl]
if {{$registered != 1 || $distributed != 1 || $scratch != 1 || $per_cause != 1 || $rom_word != 1 || $rom_metadata != 1 || $producer_final != 1 || $checked_product != 1}} {{ error "wrong combined physical options" }}
set prior_sources [file join $evidence_dir frozen_sources]
"""
COPY_VERIFY = f"puts [exec {PYTHON_CHILD} $audit_helper --verify $evidence_dir --expected $expected_prepared --copied $source_dir]\n"
GENERIC_CHECK = """set physical_generics [get_property GENERIC [get_filesets sources_1]]
foreach {name value} [list REGISTERED_SCHEDULING $registered DISTRIBUTED_FAST_FAULT $distributed PRIVATE_NEXT_START_SCRATCH $scratch PER_CAUSE_FAULT_CDC $per_cause PRIVATE_ROM_READ_AHEAD $rom_word PRIVATE_BLOCK_METADATA_READ_AHEAD $rom_metadata PRODUCER_LOCAL_FINAL_FENCE $producer_final CHECKED_PRODUCT_BANK $checked_product] {
  if {[lsearch -exact $physical_generics ${name}=$value] < 0} { error "missing physical parameter $name" }
}
if {[lsearch -all -inline -glob $physical_generics PER_CAUSE_FAULT_CDC=*] ne [list PER_CAUSE_FAULT_CDC=1]} {
  error "requires exactly one explicit C1 physical parameter"
}
foreach name {PRIVATE_ROM_READ_AHEAD PRIVATE_BLOCK_METADATA_READ_AHEAD PRODUCER_LOCAL_FINAL_FENCE CHECKED_PRODUCT_BANK} {
  if {[lsearch -all -inline -glob $physical_generics ${name}=*] ne [list ${name}=1]} {
    error "requires exactly one explicit ROM physical parameter $name"
  }
}
"""


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("nonunique synthesis adapter anchor")
    return text.replace(old, new, 1)


def adapt_synthesis(original):
    changes = (
        (
            'if {$argc != 2} { error "expected NEW_OUTPUT PASSED_SIMULATION_DIRECTORY" }',
            'if {$argc != 3} { error "expected NEW_OUTPUT PREPARED EXPECTED_PREPARED_SHA256" }',
        ),
        (
            "set script_dir [file dirname [file normalize [info script]]]",
            "set script_dir [file join [file dirname [file normalize [info script]]] frozen_sources]",
        ),
        (LEGACY_ADMISSION, ADMISSION),
        (
            'puts $channel "source_simulation=$evidence_dir"\n',
            (
                'puts $channel "source_preparation=$evidence_dir"\n'
                'puts $channel "expected_preparation_sha256=$expected_prepared"\n'
                'puts $channel "source_simulation_log=$simlog"\n'
            ),
        ),
        (
            "  REGISTERED_SCHEDULING=$registered] [get_filesets sources_1]\n",
            "  REGISTERED_SCHEDULING=$registered DISTRIBUTED_FAST_FAULT=$distributed \\\n  PRIVATE_NEXT_START_SCRATCH=$scratch PER_CAUSE_FAULT_CDC=$per_cause PRIVATE_ROM_READ_AHEAD=$rom_word PRIVATE_BLOCK_METADATA_READ_AHEAD=$rom_metadata PRODUCER_LOCAL_FINAL_FENCE=$producer_final CHECKED_PRODUCT_BANK=$checked_product] [get_filesets sources_1]\n"
            + GENERIC_CHECK,
        ),
        (
            'puts $channel "registered_scheduling=$registered"\n',
            (
                'puts $channel "registered_scheduling=$registered"\n'
                'puts $channel "distributed_fast_fault=$distributed; private_next_start_scratch=$scratch; per_cause_fault_cdc=$per_cause; private_rom_read_ahead=$rom_word; private_block_metadata_read_ahead=$rom_metadata; producer_local_final_fence=$producer_final; checked_product_bank=$checked_product"\n'
                'puts $channel "effective_top_generics=$physical_generics"\n'
            ),
        ),
        (
            "launch_runs $ip_run -jobs 2\n",
            COPY_VERIFY + "launch_runs $ip_run -jobs 2\n",
        ),
        ("close_project\n", COPY_VERIFY + "close_project\n"),
    )
    for old, new in changes:
        original = once(original, old, new)
    for old, new in (
        ("starlink_pss_fft_bank_owned_slice", "starlink_pss_fft_bank_owned_product_fence"),
        ("starlink_pss_forward_kernel_join", "starlink_pss_forward_kernel_join_read_ahead"),
        ("starlink_pss_kernel_rom", "starlink_pss_kernel_rom_read_ahead"),
    ):
        original = original.replace(old, new)
    original = once(original,
        "starlink_pss_realtime_result_guard starlink_pss_block_mailbox\n",
        "starlink_pss_realtime_result_guard starlink_pss_block_mailbox starlink_pss_product_fence_mailbox\n")
    original = once(original, "set_property top starlink_pss_fft_bank_owned_product_fence",
        "set_property top starlink_pss_fft_bank_owned_checked_product")
    original = once(original, "set rtl_names {", "set rtl_names {starlink_pss_fft_bank_owned_checked_product starlink_pss_realtime_checked_product_input_guard starlink_pss_realtime_result_guard_observe starlink_pss_checked_product_read_observe starlink_pss_product_sealed_observe starlink_pss_epoch_sealed_publication_bank ")
    return original


def verify_actual(actual):
    owner = actual.parent / "checked-drain-actual-parent.wlpL6hYk"
    for anchor in (actual, owner):
        if any(p.is_symlink() for p in (anchor, *anchor.parents)):
            raise ValueError("aliased checked-product actual evidence")
    # Original owner completion is mandatory; never infer PASS from a live log.
    outcome = json.loads((owner / "outcome.json").read_text())
    required = {"vendor_exit": 0, "timed_out": False, "interruption": None,
        "source_pins_unchanged": True, "live_sources_unchanged": True,
        "generated_wrapper_matches_known": True, "result_exit": 0,
        "functional_accepted": True, "physical_qualified": False,
        "deployment_eligible": False}
    if any(type(outcome.get(k)) is not type(v) or outcome[k] != v for k, v in required.items()):
        raise ValueError("checked actual pending/failed/unqualified outcome")
    if sha(owner / "owner.py") != "d43778ae62b057bd5c08a7101d2f8556cac1a5199f61331498aa5c0c728b393d":
        raise ValueError("checked actual owner changed")
    if sha(actual / "SHA256SUMS") != ACTUAL_INVENTORY:
        raise ValueError("requires exact checked actual89 inventory")
    rows = {}
    for line in (actual / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = actual / name
        if name in rows or Path(name).is_absolute() or ".." in Path(name).parts or any(
                p.is_symlink() for p in (path, *path.parents)) or sha(path) != expected:
            raise ValueError("checked actual source changed: " + name)
        rows[name] = expected
    pins = json.loads((owner / "input-pins.json").read_text())
    after = json.loads((owner / "after-sources.json").read_text())
    if len(rows) != 89 or pins["manifest"] != ACTUAL_INVENTORY or pins["files"] != rows or after != {
            "manifest_unchanged": True, "source_errors": [], "live_errors": []}:
        raise ValueError("checked actual pre/post source closure differs")
    execution = json.loads((owner / "execution.json").read_text())
    if any(type(execution.get(k)) is not type(required[k]) or execution[k] != required[k]
            for k in ("vendor_exit", "timed_out", "interruption")):
        raise ValueError("original checked actual process failed")
    cli = actual / "prepare_checked_product_drain_actual.py"
    if sha(cli) != "bcd3c96b3f784b6ef7a12c5750e976d6d50c8eb19d13e4c6a3de3f08bcacfe6a" or sha(
            actual / "checked_product_actual_result.py") != "a04c648779af03ba0d156215fa274e5b2d4b92af7028fc38b95e66a35e452084":
        raise ValueError("changed checked actual admission/result policy")
    env = {k: v for k, v in __import__("os").environ.items()
        if k not in ("PYTHONHOME", "PYTHONPATH", "LD_LIBRARY_PATH", "PYTHONOPTIMIZE")}
    check = subprocess.run([PYTHON, "-B", str(cli), "--verify-result", str(actual)],
        cwd="/", env=env, capture_output=True, text=True, timeout=90, check=False)
    if check.returncode:
        raise ValueError("frozen checked actual result rejected: " + check.stderr)
    result = json.loads(check.stdout)
    drain = result.get("final_drain_witnesses")
    if not isinstance(drain, dict) or drain.get("scope") != "two_final_live_preedge_drains_after_unchanged_full_result_gate":
        raise ValueError("requires complete frozen drain-aware result")
    markers = drain.get("markers")
    if (not isinstance(markers, list) or len(markers) != 2 or any(
            not isinstance(row, list) or len(row) != 5 or any(type(value) is not int for value in row)
            for row in markers) or [row[:2] for row in markers] != [[0, 32], [1, 6]] or any(
            row[2] < 0 or row[3] - row[2] != row[4] or not 0 < row[4] <= 5215 for row in markers)):
        raise ValueError("requires exact two final drain receipts")
    old = json.loads((owner / "result-check.json").read_text())
    if type(old["exit"]) is not int or old["exit"] != 0 or json.loads(old["stdout"]) != result:
        raise ValueError("independent checked result differs from original owner")
    frozen = actual / "frozen_sources"
    binding = runpy.run_path(str(actual / "prepare_checked_product_actual.py"))
    metadata = json.loads((actual / "drain-preparation.json").read_text())
    if metadata["settings"] != SETTINGS or set(binding["RUNTIME_SHA"]) != set(RTL):
        raise ValueError("checked runtime/settings closure differs")
    for name, digest in binding["RUNTIME_SHA"].items():
        if sha(frozen / name) != digest:
            raise ValueError("checked runtime changed: " + name)
    ip = json.loads((owner / "generated-ip-after.json").read_text())
    files = ip["files"]
    if len(files) != 19:
        raise ValueError("incomplete after-only generated IP receipt")
    for name, item in files.items():
        path = actual / "project" / name
        if Path(name).is_absolute() or ".." in Path(name).parts or path.is_symlink() or (
                path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]):
            raise ValueError("changed after-only generated IP")
    launch = (owner / "stdout.log").read_text()
    marker = "CHECKED_PRODUCT_ACTUAL_VENDOR_VERIFIED_CHANGED_LATENCY_NO_RAW217_NO_PHYSICAL_OR_RF_CLAIM"
    if re.findall(r"^" + marker + r"$", launch, re.MULTILINE) != [marker] or re.search(
            r"fatal_error|fatal:|error:|segmentation fault|kernel.*crash", launch, re.IGNORECASE):
        raise ValueError("missing/failed checked actual runner completion")
    return {"actual_directory": str(actual.resolve()), "inventory_sha256": ACTUAL_INVENTORY,
        "settings": SETTINGS, "source_sha256": {n: sha(frozen / n) for n in SOURCE_NAMES
            if n not in ("fft_bank_owned_resource_probe.xdc", "fft_bank_owned_synth_threads.tcl")},
        "qualified_observer": result, "generated_IP_after_only": ip,
        "owner_receipts_sha256": {n: sha(owner / n) for n in ("owner.py", "outcome.json",
            "input-pins.json", "after-sources.json", "execution.json", "result-check.json", "stdout.log")}}


def bindings(actual):
    path = str(
        Path(actual["actual_directory"])
        / "project/exact_control_actual.sim/sim_1/behav/xsim/simulate.log"
    )
    if any(char in path for char in "{}\\\r\n"):
        raise ValueError("unsupported Tcl path characters")
    options = actual["settings"]
    return (
        f"set registered {options['REGISTERED_SCHEDULING']}\n"
        f"set distributed {options['DISTRIBUTED_FAST_FAULT']}\n"
        f"set per_cause {options['PER_CAUSE_FAULT_CDC']}\n"
        f"set rom_word {options['PRIVATE_ROM_READ_AHEAD']}\n"
        f"set rom_metadata {options['PRIVATE_BLOCK_METADATA_READ_AHEAD']}\n"
        f"set producer_final {options['PRODUCER_LOCAL_FINAL_FENCE']}\n"
        f"set checked_product {options['CHECKED_PRODUCT_BANK']}\n"
        f"set scratch {options['PRIVATE_NEXT_START_SCRATCH']}\nset simlog {{{path}}}\n"
    )


def verify_prepared(prepared, copied=None, expected_inventory=None):
    if (
        expected_inventory is not None
        and sha(prepared / "SHA256SUMS") != expected_inventory
    ):
        raise ValueError("prepared inventory changed from reviewed identity")
    subprocess.run(
        ["sha256sum", "-c", "SHA256SUMS", "--quiet"],
        cwd=prepared,
        check=True,
        timeout=10,
    )
    metadata = json.loads((prepared / "physical_preparation.json").read_text())
    actual = verify_actual(Path(metadata["actual"]["actual_directory"]))
    if actual != metadata["actual"] or (
        prepared / "exact_physical_settings.tcl"
    ).read_text() != bindings(actual):
        raise ValueError("actual evidence or explicit bindings changed")
    source = prepared / "frozen_sources"
    expected_sources = {
        name: (
            FIXED[name]
            if name
            in {"fft_bank_owned_resource_probe.xdc", "fft_bank_owned_synth_threads.tcl"}
            else actual["source_sha256"][name]
        )
        for name in SOURCE_NAMES
    }
    if (
        metadata["source_sha256"] != expected_sources
        or metadata["fixed_tools_sha256"] != FIXED
    ):
        raise ValueError(
            "source identities no longer close passed actual and fixed tools"
        )
    original = prepared / "synthesize_fft_bank_owned_slice.original.tcl"
    if (
        sha(original) != FIXED["synthesize_fft_bank_owned_slice.tcl"]
        or sha(prepared / "route_completed_input_fence.tcl")
        != FIXED["route_completed_input_fence.tcl"]
        or (prepared / "synthesize_exact_control_prepared.tcl").read_text()
        != adapt_synthesis(original.read_text())
    ):
        raise ValueError("fixed physical scripts or exact adapter changed")
    if {p.name for p in source.iterdir()} != set(SOURCE_NAMES):
        raise ValueError("physical source closure has extra or missing files")
    if {p.name: sha(p) for p in source.iterdir()} != metadata["source_sha256"]:
        raise ValueError("physical source closure changed")
    if copied is not None:
        if {p.name for p in copied.iterdir()} != set(SOURCE_NAMES) | {
            "synthesize_exact_control_prepared.tcl"
        }:
            raise ValueError("copied complete input closure differs")
        for name in SOURCE_NAMES:
            if sha(copied / name) != metadata["source_sha256"][name]:
                raise ValueError("copied synthesis source differs: " + name)
        if sha(copied / "synthesize_exact_control_prepared.tcl") != sha(
            prepared / "synthesize_exact_control_prepared.tcl"
        ):
            raise ValueError("copied synthesis source differs: adapter")
    return {
        "scope": "verified_preparation_NOT_physical_execution",
        "registered": 1,
        "distributed": 1,
        "scratch": 1,
        "per_cause": 1,
        "rom_word": 1,
        "rom_metadata": 1,
        "rtl_count": 14,
        "checked_product": 1,
        "producer_final": 1,
        "qualified_observer": actual["qualified_observer"],
    }


def prepare(actual_dir, output):
    if output.exists():
        raise FileExistsError("refusing to overwrite physical preparation")
    actual = verify_actual(actual_dir)
    tools = Path(__file__).resolve().parent
    for name, expected in FIXED.items():
        if sha(tools / name) != expected:
            raise ValueError("fixed physical tool changed: " + name)
    frozen = actual_dir / "frozen_sources"
    if (
        sha(frozen / "create_shared_realtime_xfft_ip.tcl")
        != FIXED["create_shared_realtime_xfft_ip.tcl"]
    ):
        raise ValueError("actual IP factory differs")
    source = output / "frozen_sources"
    source.mkdir(parents=True)
    for name in SOURCE_NAMES:
        origin = (
            tools
            if name
            in {"fft_bank_owned_resource_probe.xdc", "fft_bank_owned_synth_threads.tcl"}
            else frozen
        )
        shutil.copyfile(origin / name, source / name)
    shutil.copyfile(__file__, output / Path(__file__).name)
    shutil.copyfile(
        tools / "run_exact_control_synthesis.py",
        output / "run_exact_control_synthesis.py",
    )
    shutil.copyfile(
        tools / "route_completed_input_fence.tcl",
        output / "route_completed_input_fence.tcl",
    )
    original = (tools / "synthesize_fft_bank_owned_slice.tcl").read_text()
    (output / "synthesize_fft_bank_owned_slice.original.tcl").write_text(original)
    (output / "synthesize_exact_control_prepared.tcl").write_text(
        adapt_synthesis(original)
    )
    (output / "exact_physical_settings.tcl").write_text(bindings(actual))
    metadata = {
        "scope": "OFFLINE_ONLY_checked_product14_physical_preparation_NO_synthesis_route",
        "actual": actual,
        "fixed_tools_sha256": FIXED,
        "source_sha256": {p.name: sha(p) for p in sorted(source.iterdir())},
    }
    (output / "physical_preparation.json").write_text(
        json.dumps(metadata, indent=2) + "\n"
    )
    files = sorted(p for p in output.rglob("*") if p.is_file())
    (output / "SHA256SUMS").write_text(
        "".join(f"{sha(p)}  {p.relative_to(output)}\n" for p in files)
    )
    return verify_prepared(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--actual", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--verify", type=Path)
    parser.add_argument("--expected")
    parser.add_argument("--copied", type=Path)
    args = parser.parse_args()
    if (
        args.verify is not None
        and args.actual is None
        and args.output is None
        and args.expected is not None
    ):
        result = verify_prepared(args.verify, args.copied, args.expected)
    elif (
        args.actual is not None
        and args.output is not None
        and args.verify is None
        and args.copied is None
        and args.expected is None
    ):
        result = prepare(args.actual, args.output)
    else:
        parser.error(
            "choose --actual/--output or --verify/--expected with optional --copied"
        )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
