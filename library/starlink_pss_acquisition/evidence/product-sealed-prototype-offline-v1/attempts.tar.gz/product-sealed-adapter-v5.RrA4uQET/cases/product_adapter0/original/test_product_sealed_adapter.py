"""Standalone issuer + real guards/product; not a vendor FFT/top integration."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

import pytest

from tests.starlink_oracle.test_checked_product_read import clean_env

ROOT = Path(__file__).resolve().parents[2]
ACQ = ROOT / "hdl/library/starlink_pss_acquisition"
NAMES = ["starlink_pss_product_sealed_adapter.v", "starlink_pss_checked_product_read.v",
         "starlink_pss_epoch_sealed_bank.v", "starlink_pss_block_mailbox.v",
         "starlink_pss_realtime_input_guard.v", "starlink_pss_realtime_result_guard.v",
         "starlink_pss_spectrum_product.v", "tb/tb_starlink_pss_product_sealed_adapter.sv"]


def compile_case(path, mutation=None):
    path.mkdir()
    for name in NAMES:
        shutil.copyfile(ACQ / name, path / Path(name).name)
    shutil.copyfile(Path(__file__), path / Path(__file__).name)
    shutil.copyfile(Path(__file__).with_name("test_checked_product_read.py"), path / "test_checked_product_read.py")
    if mutation:
        name, old, new = mutation
        p = path / name
        source = p.read_text()
        assert source.count(old) == 1
        p.write_text(source.replace(old, new))
    (path / "sources.json").write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in path.iterdir() if p.is_file()}, indent=2))
    command = ["iverilog", "-g2012", "-Wall", "-s", "tb_starlink_pss_product_sealed_adapter",
               "-o", "sim.vvp", *[Path(n).name for n in NAMES]]
    p = subprocess.run(command, cwd=path, env=clean_env(), text=True, capture_output=True, timeout=30, check=False)
    (path / "compile.log").write_text(p.stdout + p.stderr)
    (path / "compile.json").write_text(json.dumps({"command": command, "exit": p.returncode}))
    assert p.returncode == 0 and not re.search(r"(?im)^.*error:", p.stderr), p.stderr
    return path


@pytest.fixture(scope="module")
def compiled(tmp_path_factory):
    return compile_case(tmp_path_factory.mktemp("product_adapter") / "original")


def execute(path, kind=0, bit=0, target=37):
    command = ["vvp", "sim.vvp", f"+CASE={kind}", f"+BIT={bit}", f"+TARGET={target}"]
    p = subprocess.run(command, cwd=path, env=clean_env(), text=True, capture_output=True, timeout=30, check=False)
    log = p.stdout + p.stderr
    name = f"case-{kind}-bit-{bit}-target-{target}"
    (path / f"{name}.log").write_text(log)
    (path / f"{name}.json").write_text(json.dumps({"command": command, "exit": p.returncode}))
    return p.returncode, log


def test_eight_actual_guard_product_leases_complete(compiled):
    code, log = execute(compiled)
    assert code == 0 and "PRODUCT_ADAPTER_PASS case=0 jobs=8" in log, log
    assert log.count("take=512 seal_delta=2 publish_delta=3") == 8, log


@pytest.mark.parametrize("target", [0, 37, 511])
def test_real_arithmetic_overflow_never_publishes(compiled, target):
    code, log = execute(compiled, 1, target=target)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=1" in log, log


def test_prefetch_final_waits_actual_guard_complete(compiled):
    code, log = execute(compiled, 2)
    assert code == 0 and "PRODUCT_ADAPTER_PASS case=2 jobs=1" in log, log


@pytest.mark.parametrize("bit", range(8))
def test_all_current_faults_and_private_reset_preserve_poison(compiled, bit):
    code, log = execute(compiled, 3, bit)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=3" in log, log


@pytest.mark.parametrize("bit", range(70))
@pytest.mark.parametrize("target", [0, 37, 511])
def test_all_actual_product_metadata_bits(compiled, bit, target):
    code, log = execute(compiled, 4, bit, target)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=4" in log, log


@pytest.mark.parametrize("bit", range(75))
@pytest.mark.parametrize("target", [3, 37, 511])
def test_all_raw_bank_read_bits_including_full_queue_stall(compiled, bit, target):
    code, log = execute(compiled, 5, bit, target)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=5" in log, log


@pytest.mark.parametrize("bit", range(8))
@pytest.mark.parametrize("target", range(4))
def test_current_causes_on_seal_publish_handoff_release_edges(compiled, bit, target):
    code, log = execute(compiled, 6, bit, target)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=6" in log, log


@pytest.mark.parametrize("target", [0, 37, 511])
def test_real_consumer_duplicate_start_veto(compiled, target):
    code, log = execute(compiled, 7, target=target)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=7" in log, log


@pytest.mark.parametrize("target", [0, 1, 2])
@pytest.mark.parametrize("bit", [0, 69, 74])
def test_taken_head_words_checked_before_handoff(compiled, target, bit):
    code, log = execute(compiled, 5, bit, target)
    assert code == 0 and "PRODUCT_ADAPTER_NEGATIVE_PASS case=5" in log, log


@pytest.mark.parametrize("delay", [0, 1, 2])
def test_stalled_corruption_onset_before_current_after_handoff(compiled, delay):
    code, log = execute(compiled, 8, 74, delay)
    assert code == 0 and "PRODUCT_ADAPTER_ONSET_PASS" in log, log
    row = re.search(r"handoffs=(\d+) corruption=(\d+) verdict=(\d+) head=(-?\d+) received=(\d+)", log)
    assert row and int(row[5]) <= 3, log
    if delay == 0:
        assert int(row[1]) == 0, log
    else:
        assert int(row[1]) == 1 and int(row[3]) > int(row[4]), log


@pytest.mark.parametrize("mutation,kind,bit,target,marker", [
    (("starlink_pss_product_sealed_adapter.v", " && !queue_validation_fault;", ";"),
     5, 74, 3, "POISONED_PREFETCH_HANDOFF"),
    (("starlink_pss_product_sealed_adapter.v", "input_metadata({5'b0,product_metadata})", "input_metadata({expected_metadata[74:5],product_metadata[4:0]})"),
     4, 69, 37, "PREHANDOFF_FAULT_NOT_QUARANTINED"),
    (("starlink_pss_product_sealed_adapter.v", "wire certificate_valid = completion_reference && !certificate_consumed;",
      "wire certificate_valid = producer_reference && !certificate_consumed;"),
     0, 0, 37, "CERTIFIED_HANDOFF_MISSING"),
    (("starlink_pss_product_sealed_adapter.v", "handoff_seen && queue_drained &&", "handoff_seen && queue_final &&"),
     9, 0, 37, "LEASE_RELEASE_BEFORE_CERTIFIED_FINAL_DRAIN"),
])
def test_executed_issuer_lifetime_mutants(tmp_path, mutation, kind, bit, target, marker):
    path = compile_case(tmp_path / "mutant", mutation)
    code, log = execute(path, kind, bit, target)
    assert code != 0 and marker in log, log


def test_real_completion_certificate_delivery_hold(compiled):
    code, log = execute(compiled, 9)
    assert code == 0 and "PRODUCT_ADAPTER_PASS case=9 jobs=1" in log, log
