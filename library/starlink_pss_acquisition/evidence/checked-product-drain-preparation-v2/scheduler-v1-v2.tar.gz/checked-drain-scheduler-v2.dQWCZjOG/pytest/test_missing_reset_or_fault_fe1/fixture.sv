`timescale 1ns/1ps
module actor;
  localparam WAIT_BANK=2;
  reg fast_running=1, fast_fault=0, next_inverse=0, result_busy=0, output_bank_ready=1;
  reg [3:0] state=1;
endmodule
module tb;
  actor dut();
  reg fft_clk=0, clk=1, fault=0;
  integer fast_cycle=0, previous_admit=-1, published=32, profile=0, live_samples=0;
  real last_live=-1;
  always #5 fft_clk=~fft_clk;
  always @(negedge fft_clk) fast_cycle=fast_cycle+1;
  always @(posedge fft_clk) begin
    if (dut.fast_running===1'b1 && dut.fast_fault===1'b0 && fault===1'b0 &&
        published===32 && dut.state===dut.WAIT_BANK && dut.next_inverse===1'b0 &&
        dut.result_busy===1'b0 && dut.output_bank_ready===1'b1) begin
      live_samples=live_samples+1; last_live=$realtime;
    end
  end
  task automatic tick;
    @(posedge fft_clk); #0.001;
  endtask
  task automatic await_results(input integer count);
    integer timeout;
    timeout = 0;
    while ((published != count || dut.state != dut.WAIT_BANK || dut.next_inverse) && timeout < 25000) begin
      tick(); timeout = timeout + 1;
    end
    if (timeout == 25000 || fault) $fatal(1, "outputs/final real ACK failed to drain");
  endtask
  // Observe the same live pre-edge drain required by the complete CSV gate.
  // await_results may first see WAIT_BANK after NBA; do not reset before a
  // following live trace sample. The original 5215-clock service bound applies.
  task automatic checked_profile_drain(input integer count);
    reg observed;
    integer drain_cycle, service_cycles;
    observed = 0;
    while (!observed) begin
      @(posedge fft_clk);
      if (dut.fast_running !== 1'b1 || fault !== 1'b0)
        $fatal(1, "CHECKED_PROFILE_DRAIN_RESET_OR_FAULT");
      drain_cycle = fast_cycle;
      service_cycles = drain_cycle - previous_admit;
      if (previous_admit < 0 || service_cycles <= 0 || service_cycles > 5215)
        $fatal(1, "CHECKED_PROFILE_DRAIN_SERVICE_BOUND");
      observed = published === count && dut.state === dut.WAIT_BANK &&
        dut.next_inverse === 1'b0 && dut.result_busy === 1'b0 &&
        dut.output_bank_ready === 1'b1;
      #0.001;
      if (dut.fast_running !== 1'b1 || fault !== 1'b0)
        $fatal(1, "CHECKED_PROFILE_DRAIN_RESET_OR_FAULT");
    end
    $display("CHECKED_PROFILE_DRAIN_WITNESS profile=%0d count=%0d forward=%0d drain=%0d service=%0d",
      profile, count, previous_admit, drain_cycle, service_cycles);
  endtask

  initial begin
    dut.state=dut.WAIT_BANK; previous_admit=0; fast_cycle=1; dut.fast_fault=1;
    checked_profile_drain(32);
    if (live_samples != 1) $fatal(1,"MISSING_CURRENT_RESET_FAULT_FENCE"); $finish;
  end

endmodule
